package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class AddTargetProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(AddTargetProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	AddTargetProtectionGroupTaskConfig config = (AddTargetProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

         String targets = config.getTargets();
        String protectionGroupName = config.getProtectionGroup();
        
        List<PureProtectionGroup> protectiongroups =  CLIENT.protectionGroups().list();
        

            try
            {
                CLIENT.protectionGroups().addTargets(protectionGroupName, Arrays.asList(targets));
            }
            catch(Exception e) {
                actionlogger.addError("Please check the Protection Group Name " + protectionGroupName + "and target Details.");
                throw e;
            }

           
            
             actionlogger.addInfo("Added Target " + targets + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           context.getChangeTracker().undoableResourceModified("Added Targets in Protection Group", "Added Targets in Protection Group", "Added Targets in Protection Group",
                    "Added Targets in Protection Group" + config.getAccountName(),
                    new RemoveTargetProtectionGroupTask().getTaskName(), new RemoveTargetProtectionGroupTaskConfig(config));
            String targetIdentity =accountName+"@"+targets;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_CONNECTIONARRAY_IDENTITY, targetIdentity);
        	actionlogger.addInfo("Target Identity as Output is saved");
        	
        	String addedTarget="";
        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
       	   
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgconfig = store2.query(query3);
            actionlogger.addInfo("Target :"+ pgconfig.get(0).getId());
            //pgconfig.get(0).getHosts();
            String TargetList1= pgconfig.get(0).getTargets();
            
    		logger.info(" Target :"+ TargetList1);
    		
    			if(TargetList1 == "")
    					{
    					pgconfig.get(0).setTargets(targets);
    				}else
    						{
    						TargetList1=TargetList1+","+targets;
    						pgconfig.get(0).setTargets(TargetList1);
    						}
          
           
            
            store2.modifySingleObject("targets == " + TargetList1 ,  pgconfig.get(0));
            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
            actionlogger.addInfo("Targets :"+ pgconfig1.get(0).getTargets());
            
            }
    
   
    
    
          
        
        

    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_CONNECTIONARRAY_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"TARGET Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new AddTargetProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_ADD_CONNECTIONARRAY_PROTECTIONGROUP_TASK;
	}

}