package com.cloupia.feature.purestorage.actions;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.actions.forms.RemoveHostProtectionGroupForm;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.tasks.RemoveHostProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.RemoveHostProtectionGroupTaskConfig;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.model.cIM.ConfigTableAction;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.service.cIM.inframgr.forms.wizard.Page;
import com.cloupia.service.cIM.inframgr.forms.wizard.PageIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaPageAction;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class RemoveHostProtectionGroup extends CloupiaPageAction {

	private static Logger logger = Logger.getLogger(RemoveHostProtectionGroup.class);
	
	private static final String formId = "psucs.remove.host.protectiongroup.form";
	private static final String ACTION_ID = "psucs.remove.host.protectiongroup.action";
	private static final String label = "Remove Host";
	
	@Override
	public void definePage(Page page, ReportContext context) {
		// TODO Auto-generated method stub
		page.bind(formId, RemoveHostProtectionGroupForm.class);
	}

	@Override
	public void loadDataToPage(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub
		RemoveHostProtectionGroupForm form = (RemoveHostProtectionGroupForm) page.unmarshallToSession(formId);
		
		
		
		
		page.marshallFromSession(formId);
	}

	@Override
	public int validatePageData(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub
		RemoveHostProtectionGroupForm config = (RemoveHostProtectionGroupForm) page.unmarshallToSession(formId);
		
		


		if (page.isPageSubmitted())
        {
			try{
				
				String accountName = "",protectionGroupName = "" ;
				PureRestClient CLIENT = null;
				if(context.getId().contains("@"))   //Checking the Context 
		        {
		        	 String[] parts = context.getId().split("@",2);
		             accountName = parts[0];
		             protectionGroupName = parts[1];
		           	
		        }
		        else
		        {
		        	logger.error("Error in Report Generation ..Wrong Conext" + context);
		            
		        }
				 
		       logger.info("finished checking NewHostTask accoutname");
		       FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
		       CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);
		       String hostName = config.getHostName();
		         
		        List<PureProtectionGroup> protectiongroups =  CLIENT.protectionGroups().list();
		        


	            try
	            {
	                CLIENT.protectionGroups().removeHosts(protectionGroupName,Arrays.asList(hostName));
	            }
	            catch(Exception e) {
	                logger.error("There is no exsiting Host " + hostName + "in Protection GRoup.");
	                throw e;
	            }

	           
	            
	             logger.info("Removing host " + hostName + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
	        
	           /* context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "Scheduled Snapshot",
	                    "Snapshots have been scheduled" + config.getAccountName(),
	                    new DeleteScheduleSnapshotTask().getTaskName(), new DeleteScheduleSnapshotTaskConfig(config));
	         */   String volIdentity =accountName+"@"+hostName;
	            //String snapIdentity =accountName+"@"+snapShotName;
	            
	            
	        
	        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
	        	   
	        	
	            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
	            List<ProtectionGroupInventoryConfig> pgConfig = store2.query(query3);
	            logger.info("Host Name :"+ pgConfig.get(0).getId());
	            //pgconfig.get(0).getHosts();
	            String hostsList1= "";
	            PureProtectionGroup protectiongroup=CLIENT.protectionGroups().get(protectionGroupName);
	    		logger.info(" Host :"+ hostsList1);
	    		
	    		if(protectiongroup.getHosts().isEmpty())
	    		{
	    			pgConfig.get(0).setHosts("");
	    		}
	    	else
	    		{
	    		
	    	
	    		List<String> hostList = protectiongroup.getHosts();
	    		String hostsList2="";
	    		logger.info(" Host :"+ hostsList2);
	    		for(String hos1 : hostList)
	    			{
	    				if(hostsList2 == "")
	    					{
	    						hostsList2=hos1;
	    					}else
	    						{
	    						hostsList2=hostsList2+","+hos1;
	    						}
	          }
	          	pgConfig.get(0).setHosts(hostsList2);
	    				  
	    	            store2.modifySingleObject("hosts == '" + hostsList2 + "'",  pgConfig.get(0));
	    	            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
	    	            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
	    	            logger.info("Host Name :"+ pgconfig1.get(0).getHosts());
	    		}
	    	           
	              
		      
	                page.setPageMessage("Successfully created host " + hostName + "on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
	  	          return PageIf.STATUS_OK;
				
				
	        	
	        }catch(Exception ex){
	        	page.setPageMessage("Error: "+ex.getMessage());
	        	return PageIf.STATUS_ERROR;
	        }
        }
		return PageIf.STATUS_OK;
	}

	@Override
	public String getActionId() {
		// TODO Auto-generated method stub
		return ACTION_ID;
	}

	@Override
	public int getActionType() {
		// TODO Auto-generated method stub
		return ConfigTableAction.ACTION_TYPE_POPUP_FORM;
	}

	@Override
	public String getFormId() {
		// TODO Auto-generated method stub
		return formId;
	}

	@Override
	public String getLabel() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public boolean isDoubleClickAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDrilldownAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelectionRequired() {
		// TODO Auto-generated method stub
		return true;
	}

}
