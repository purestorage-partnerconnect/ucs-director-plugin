package com.cloupia.feature.purestorage;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hellooo6y7u5ooooooooooooooo");
	}

}
