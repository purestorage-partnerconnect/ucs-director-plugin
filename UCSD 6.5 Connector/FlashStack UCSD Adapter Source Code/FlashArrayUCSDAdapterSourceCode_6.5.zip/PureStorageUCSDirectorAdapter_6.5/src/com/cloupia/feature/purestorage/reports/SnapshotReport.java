package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.actions.AddVolume;
import com.cloupia.feature.purestorage.actions.CloneSnapshot;
import com.cloupia.feature.purestorage.actions.CopyVolume;
import com.cloupia.feature.purestorage.actions.DestroySnapshot;
import com.cloupia.feature.purestorage.actions.DestroyVolume;
import com.cloupia.feature.purestorage.actions.ResizeVolume;
import com.cloupia.feature.purestorage.actions.RestoreVolumeFromSnapshot;
import com.cloupia.feature.purestorage.actions.ScheduleVolumeSnapshot;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.model.cIM.DynReportContext;
import com.cloupia.model.cIM.ReportContextRegistry;
import com.cloupia.service.cIM.inframgr.reportengine.ContextMapRule;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReportAction;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReportWithActions;
import com.cloupia.service.cIM.inframgr.reports.simplified.actions.DrillDownAction;

public class SnapshotReport extends CloupiaReportWithActions
{

    private static Logger logger = Logger.getLogger(SnapshotReport.class);

    public SnapshotReport()
    {
        super();
        this.setMgmtColumnIndex(0);
    }

    @Override
    public CloupiaReportAction[] getActions()
    {
        //return null;
    	
    	
    	CloneSnapshot copyaction = new CloneSnapshot();
    	RestoreVolumeFromSnapshot restore = new RestoreVolumeFromSnapshot();
    	DestroySnapshot delaction = new DestroySnapshot();
    	
		CloupiaReportAction[] actions = new CloupiaReportAction[3];
		
		
		actions[0] = copyaction;
		actions[1] = restore;
		actions[2] = delaction;
		
		return actions;
    }

    @Override
    public Class<?> getImplementationClass()
    {
        return SnapshotReportImpl.class;
    }

    @Override
    public String getReportLabel()
    {
        return "Snapshots";
    }

    @Override
    public String getReportName()
    {
        return "com.purestorage.flasharray.snapshot";
    }

    @Override
    public boolean isEasyReport()
    {
        return false;
    }

    @Override
    public boolean isLeafReport()
    {
        return true;
    }

    @Override
    public int getMenuID()
    {
        return PureConstants.SNAPSHOT_REPORT_MENU_LOCATION;
    }

    @Override
    public ContextMapRule[] getMapRules()
    {
        DynReportContext context = ReportContextRegistry.getInstance().getContextByName(PureConstants.PURE_ACCOUNT_TYPE);
        logger.info("ContextMapRule: context Id:" + context.getId());
        logger.info("ContextMapRule: ContextType:" + context.getType());
        ContextMapRule rule = new ContextMapRule();
        rule.setContextName(context.getId());
        rule.setContextType(context.getType());

        ContextMapRule[] rules = new ContextMapRule[1];
        rules[0] = rule;

        return rules;
    }
    
    @Override
   	public boolean showInSummary()
   	{
   		return false;
   	}

}