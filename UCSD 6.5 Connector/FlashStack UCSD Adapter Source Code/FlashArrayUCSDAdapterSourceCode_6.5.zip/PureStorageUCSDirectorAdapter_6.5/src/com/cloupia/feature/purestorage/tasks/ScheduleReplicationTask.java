package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;


public class ScheduleReplicationTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(ScheduleReplicationTask.class);
	
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	ScheduleReplicationTaskConfig config = (ScheduleReplicationTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking NewHostTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        String protectionGroup = config.getProtectionGroupName();
             
       	String cF= config.getCreateFrequency();
        	if (cF.equals(""))cF= "0";            
            int  createFrequency = Integer.valueOf(cF);
            String fU = config.getFrequencyUnit();
            int fU1 = 0;
            if(fU.equals("m")) fU1= 60;
            else if(fU.equals("h")) fU1 =3600;
            else if(fU.equals("d")) fU1 =3600*24;
            else fU1 =0;            	
            int frequencyUnit = fU1;
            String sT = config.getSetTime();
            if(sT.equals("")) sT="0";
            int setTime = Integer.valueOf(sT) * 3600;
            String rP = config.getRetainPeriod();
            if(rP.equals("")) rP="0";
            int retainPeriod = Integer.valueOf(rP);
            String rU = config.getRetainUnit();
            int rU1=0;
            if(rU.equals("m")) rU1= 60;
            else if(rU.equals("h")) rU1 =3600;
            else if(rU.equals("d")) rU1 =3600*24;
            else rU1 =0;            	
            int retainUnit = rU1;
            String rN = config.getRetainNumber();
            if(rN.equals("")) rN="0";
            int retainSnapshot = Integer.valueOf(rN);
            String d = config.getMoreDuration();
            if(d.equals("")) d="0";
            int duration = Integer.valueOf(d);
            int frequency = createFrequency * frequencyUnit;
            int period = retainPeriod * retainUnit;
            

          

            CLIENT.protectionGroups().enableReplication(protectionGroup);

            if(frequencyUnit == 3600*24 && createFrequency >0)
            {
            	
                CLIENT.protectionGroups().setSchedule(protectionGroup, null, null, setTime, frequency, null);
            }
            else
            {
            	
            	
                CLIENT.protectionGroups().setSchedule(protectionGroup, null, null, null, frequency, null);
            }
            
            CLIENT.protectionGroups().setRetention(protectionGroup,  null, null, null,  period, retainSnapshot, duration);
            
              

             


           
              
              actionlogger.addInfo("Scheduled replication for protectiongroup " + protectionGroup + "on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           /* context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "Scheduled Snapshot",
                    "Snapshots have been scheduled" + config.getAccountName(),
                    new DeleteScheduleReplicationTask().getTaskName(), new DeleteScheduleReplicationTaskConfig(config));
           */ String pgIdentity =accountName+"@"+protectionGroup;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY, pgIdentity);
        	actionlogger.addInfo("ProtectionGroup Identity as Output is saved");
        	

            
           }
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"protectionGroup Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new ScheduleReplicationTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_SCHEDULE_PROTECTIONGROUP_REPLICATION;
	}

}