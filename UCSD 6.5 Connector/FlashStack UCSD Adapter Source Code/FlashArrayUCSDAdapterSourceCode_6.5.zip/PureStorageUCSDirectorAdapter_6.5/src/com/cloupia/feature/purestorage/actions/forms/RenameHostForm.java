package com.cloupia.feature.purestorage.actions.forms;

import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class RenameHostForm {
	

	@FormField(label = "New Host Name", help = "FlashArray Host Name", mandatory = true)
    private String hostName;

   
	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	
}
