package com.cloupia.feature.purestorage.tasks;


import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.NetworkInterfaceListTabularProvider;
import com.cloupia.feature.purestorage.lovs.SubnetTabularProvider;
import com.cloupia.feature.purestorage.lovs.VolumeTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;

@XmlRootElement(name = "FlashArrayCreateVlan")
@PersistenceCapable(detachable = "true", table = "psucs_create_vlan_task_config")
public class CreateVlanTaskConfig implements TaskConfigIf 
{

    @FormField(label = "FlashArray Account", help = "FlashArray Account", mandatory=true, type=FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = FlashArrayAccountsNameProvider.NAME)
    @UserInputField(type = PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME)
    @Persistent
    private String accountName;

    @MoReference(path = "FlashArray.ID.Vlan.ID", key = true)
    @FormField(label = "Network Interface", help = "Use ',' to seperate Interface", mandatory = true,multiline = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table= NetworkInterfaceListTabularProvider.TABULAR_PROVIDER)
    @UserInputField(type = PureConstants.PURE_NETWORK_INTERFACE_LIST_TABLE_NAME)
    @Persistent
    private String networkInterface;
   

    @FormField(label = "Vlan Id", help = "Vlan Id", mandatory = true)
    @UserInputField(type = WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String vlan;
    
    @FormField(label = "Subnet Name", help = "Use ',' to seperate Subnet Name", mandatory = true,multiline = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table= SubnetTabularProvider.TABULAR_PROVIDER)
    @UserInputField(type = PureConstants.PURE_SUBNET_LIST_TABLE_NAME)
    @Persistent
    private String subnet;
    
    
    @FormField(label = "Address", help = "IPv4 Address", mandatory = false)
    @UserInputField(type = WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String address;
    
    @Persistent
    private long configEntryId;

    @Persistent
    private long actionId;


    @Override
    public long getActionId(){ return actionId;}

    @Override
    public long getConfigEntryId(){return configEntryId;}

 

    @Override
	public void setActionId(long arg0) {
		this.actionId = arg0;

	}

	@Override
	public void setConfigEntryId(long arg0) {
		this.configEntryId = arg0;

	}

    @Override
	public String getDisplayLabel()
    {
        return PureConstants.TASK_NAME_CREATE_VLAN_TASK;
    }

    public String getAccountName()
    {
        return accountName;
    }
    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }
    public String getNetworkInterface()
    {
        return networkInterface;
    }
    public void setNetworkInterface(String networkInterface)
    {
        this.networkInterface = networkInterface;
    }
    public String getVlan()
    {
        return vlan;
    }
    public void setVlan(String vlan)
    {
        this.vlan = vlan;
    }

    public String getSubnet()
    {
        return subnet;
    }
    public void setSubnet(String subnet)
    {
        this.subnet = subnet;
    }
    
    public String getAddress()
    {
        return address;
    }
    public void setAddress(String address)
    {
        this.address = address;
    }


}