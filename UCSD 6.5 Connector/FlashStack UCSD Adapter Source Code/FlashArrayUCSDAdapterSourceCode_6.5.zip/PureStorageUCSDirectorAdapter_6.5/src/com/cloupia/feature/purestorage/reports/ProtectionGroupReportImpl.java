package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import java.util.List;

public class ProtectionGroupReportImpl implements TabularReportGeneratorIf
{
    static Logger logger = Logger.getLogger(ProtectionGroupReportImpl.class);

    @Override
    public TabularReport getTabularReportReport(ReportRegistryEntry entry, ReportContext context) throws Exception
    {
        logger.info("Entering ProtectionGroupReportImpl.getTabularReportReport" );
        logger.info("ReportContext.getId()=" + context.getId());
        String accountName;
        if(context.getId().contains(";"))   //Checking the Context 
        {
        	 String[] parts = context.getId().split(";");
             accountName = parts[0];
           	
        }
        else
        {
           accountName = context.getId();
        }
        TabularReport report = new TabularReport();
        report.setGeneratedTime(System.currentTimeMillis());
        report.setReportName(entry.getReportLabel());
        report.setContext(context);

        TabularReportInternalModel model = new TabularReportInternalModel();
        model.addTextColumn("Id", "Id",true);
        model.addTextColumn("Account Name", "Account Name");
        model.addTextColumn("Protection Group Name", "Name of Protection Group");
        model.addTextColumn("Host Groups", "HostGroups added in Protection Group");
        model.addTextColumn("Hosts", "Hosts added in Protection Group");
        model.addTextColumn("Source","Source added in Protection Group");
        model.addTextColumn("Targets", "Targets added in Protection Group");
        model.addTextColumn("Volumes", "Volumes added in Protection Group");
        model.completedHeader();
        if (accountName != null && accountName.length() > 0)
        {
//            FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
//            PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
//            List<PureProtectionGroup> volumes =  CLIENT.volumes().list();
        	 List<ProtectionGroupInventoryConfig> protectiongroups= PureUtils.getAllPureProtectiongroup();
        	 
             for (ProtectionGroupInventoryConfig protectiongroup: protectiongroups)
             {
            	 if (accountName.equalsIgnoreCase(protectiongroup.getAccountName()))
                 {
                 	 model.addTextValue(protectiongroup.getId());
                 	 model.addTextValue(accountName);
                 	 model.addTextValue(protectiongroup.getProtectionGroupName());
                     model.addTextValue(protectiongroup.getHostgroups());
                     model.addTextValue(protectiongroup.getHosts());
                     model.addTextValue(protectiongroup.getSource());
                     model.addTextValue(protectiongroup.getTargets());
                     model.addTextValue(protectiongroup.getVolumes());
                     model.completedRow();
                 }
             }
        }

        model.updateReport(report);
        return report;
    }
}