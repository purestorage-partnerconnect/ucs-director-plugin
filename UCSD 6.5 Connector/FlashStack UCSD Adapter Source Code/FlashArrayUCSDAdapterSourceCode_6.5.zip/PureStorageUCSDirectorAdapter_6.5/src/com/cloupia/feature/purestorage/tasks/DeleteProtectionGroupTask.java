package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;


import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;


public class DeleteProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(DeleteProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	DeleteProtectionGroupTaskConfig config = (DeleteProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking NewProtectionGroupTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        String protectionGroupName = config.getProtectionGroupName();
       
     
        actionlogger.addInfo("Deleting protectionGroup " + protectionGroupName + " on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");

      
            CLIENT.protectionGroups().destroy(protectionGroupName);
            actionlogger.addInfo("Successfully deleted protectionGroup " + protectionGroupName + "on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           
            String protectionGroupIdentity =accountName+"@"+protectionGroupName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY, protectionGroupIdentity);
        	actionlogger.addInfo("ProtectionGroup Identity as Output is saved");
        	
        	String description="FlashArray ProtectionGroup is Deleted. Details are : Account Name = "+config.getAccountName()+" , ProtectionGroup Name = "+ protectionGroupName;
            
            UcsdCmdbUtils.updateRecord("FlashArray ProtectionGroup", description, 2, context.getUserId(), protectionGroupName,description);
            
            context.getChangeTracker().resourceAdded("FlashArray ProtectionGroup : Deleted", protectionGroupIdentity, protectionGroupName, description);
            /*context.getChangeTracker().undoableResourceDeleted("FlashArray ProtectionGroup", protectionGroupIdentity, protectionGroupName, description,
                    new NewProtectionGroupTask().getTaskName(), new NewProtectionGroupTaskConfig(config));*/
            
            ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
        	   
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> hconfig = store2.query(query3);
            actionlogger.addInfo("ProtectionGroup Id :"+ hconfig.get(0).getId());
        
            long s = store2.delete(query3);
            actionlogger.addInfo("Deleted in Inventory :" + s);
            
        }

        

    
    

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"ProtectionGroup Identity");
   		return ops;
    }

	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new DeleteProtectionGroupTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_DELETE_PROTECTIONGROUP_TASK;
	}


}
