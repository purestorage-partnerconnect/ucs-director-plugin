package com.cloupia.feature.purestorage.actions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.actions.forms.AddVolumeProtectionGroupForm;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.model.cIM.ConfigTableAction;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.service.cIM.inframgr.forms.wizard.Page;
import com.cloupia.service.cIM.inframgr.forms.wizard.PageIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaPageAction;
import com.purestorage.rest.PureRestClient;


public class AddVolumeProtectionGroup extends CloupiaPageAction {
	private static Logger logger = Logger.getLogger(AddVolumeProtectionGroup.class);
	
	private static final String formId = "psucs.add.volume.protectiongroup.form";
	private static final String ACTION_ID = "psucs.add.volume.protectiongroup.action";
	private static final String label = "Add Volume";

	@Override
	public void definePage(Page page, ReportContext context) {
		// TODO Auto-generated method stub
		
		page.bind(formId, AddVolumeProtectionGroupForm.class);
		
	}

	@Override
	public void loadDataToPage(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub
		AddVolumeProtectionGroupForm form = (AddVolumeProtectionGroupForm) page.unmarshallToSession(formId);
		
		
		
		
		page.marshallFromSession(formId);

	}

	@Override
	public int validatePageData(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub
		 String accountName="",protectionGroupName="";
		 AddVolumeProtectionGroupForm config = (AddVolumeProtectionGroupForm) page.unmarshallToSession(formId);
			
		 PureRestClient CLIENT = null;
		 if(context.getId().contains("@"))   //Checking the Context 
	        {
	        	 String[] parts = context.getId().split("@");
	             accountName = parts[0];
	             protectionGroupName = parts[1];
	           	
	        }
	        else
	        {
	        	logger.error("Error in Report Generation ..Wrong Conext" + context);
	            
	        }
		 logger.info("finished checking NewHostTask accoutname");
	        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
	        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

		 
		 	
	       
	        
	      
        
		if (page.isPageSubmitted())
        {
			try{
				String volumeName = config.getVolumeName();
		        

	            try
	            {
	                CLIENT.protectionGroups().addVolumes(protectionGroupName,Arrays.asList(volumeName));
	            }
	            catch(Exception e) {
	                logger.error("Please check the Protection Group Name " + protectionGroupName + "and volume Details.");
	                throw e;
	            }

	            ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
	        	   
	            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
	            List<ProtectionGroupInventoryConfig> pgconfig = store2.query(query3);
	            logger.info("Protection Group ID :"+ pgconfig.get(0).getId());
	            //pgconfig.get(0).getVolumes();
	            String volumesList1= pgconfig.get(0).getVolumes();
	            
	            logger.info(" Host :"+ volumesList1);
	    		
	    				if(volumesList1 == "")
	    					{
	    						pgconfig.get(0).setVolumes(volumeName);;
	    					}else
	    						{
	    						volumesList1=volumesList1+","+volumeName;
	    						pgconfig.get(0).setVolumes(volumesList1);
	    						}
	          
	           
	            
	            store2.modifySingleObject("volumes == '" + volumesList1 + "'",  pgconfig.get(0));
	            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
	            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
	            logger.info("Volume Name :"+ pgconfig1.get(0).getVolumes());
	            
	            logger.info("Added volume " + volumeName + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
	        
                page.setPageMessage("Successfully added volume to protectionGroup " + protectionGroupName + "on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
	        
	          
				
	        	return PageIf.STATUS_OK;
	        }catch(Exception ex){
	        	page.setPageMessage("Error: "+ex.getMessage());
	        	return PageIf.STATUS_ERROR;
	        }
        }
		return PageIf.STATUS_OK;
	}
	
	 

	@Override
	public String getActionId() {
		// TODO Auto-generated method stub
		return ACTION_ID;
	}

	@Override
	public int getActionType() {
		// TODO Auto-generated method stub
		return ConfigTableAction.ACTION_TYPE_POPUP_FORM;
	}

	@Override
	public String getFormId() {
		// TODO Auto-generated method stub
		return formId;
	}

	@Override
	public String getLabel() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public boolean isDoubleClickAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDrilldownAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelectionRequired() {
		// TODO Auto-generated method stub
		return true;
	}

	
}
