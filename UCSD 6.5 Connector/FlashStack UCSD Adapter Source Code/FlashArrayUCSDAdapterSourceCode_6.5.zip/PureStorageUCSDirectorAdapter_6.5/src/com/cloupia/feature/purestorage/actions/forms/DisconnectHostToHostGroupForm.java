package com.cloupia.feature.purestorage.actions.forms;

import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class DisconnectHostToHostGroupForm {
	
	 @FormField(label = "Host Name", help = "Use ',' to seperate hosts name", mandatory = true,multiline = true,maxLength = 1024000000,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table= HostTabularProvider.TABULAR_PROVIDER)
	    
	    private String hostName;

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	    
		
	
}
