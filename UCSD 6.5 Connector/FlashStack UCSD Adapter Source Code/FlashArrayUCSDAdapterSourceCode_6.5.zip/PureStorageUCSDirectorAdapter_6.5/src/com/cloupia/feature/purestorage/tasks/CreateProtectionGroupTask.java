package com.cloupia.feature.purestorage.tasks;


import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;


public class CreateProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(CreateProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	CreateProtectionGroupTaskConfig config = (CreateProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        
        String protectionGroupName = config.getProtectionGroup();
        
            

            try
            {
                CLIENT.protectionGroups().create(protectionGroupName);
            }
            catch(Exception e) {
                actionlogger.addError("Please check the Protection Group Name " + protectionGroupName);
                throw e;
            }

           
            
             actionlogger.addInfo("Created Protection Group  " + protectionGroupName + " on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
             
             String description="FlashArray ProtectionGroup is created. Details are : Account Name = "+config.getAccountName()+" , ProtectionGroup Name = "+ protectionGroupName;
             
             
             String pgIdentity =accountName+"@"+protectionGroupName;
             context.getChangeTracker().undoableResourceModified("FlashArray Protection Group : Created", pgIdentity, protectionGroupName, description,
                     new DeleteProtectionGroupTask().getTaskName(), new DeleteProtectionGroupTaskConfig(config));
             
             ObjStore<ProtectionGroupInventoryConfig> store = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
             
            
             //String snapIdentity =accountName+"@"+snapShotName;
             
              context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_VOLUME_NAME, protectionGroupName);

         	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY, pgIdentity);
         	actionlogger.addInfo("Protection Group Identity as Output is saved");
         	
         	
             ProtectionGroupInventoryConfig protectionGroupConfig = new ProtectionGroupInventoryConfig();
         	protectionGroupConfig.setId(pgIdentity);
         	   protectionGroupConfig.setAccountName(accountName);
             protectionGroupConfig.setProtectionGroupName(protectionGroupName); // Name
             protectionGroupConfig.setHostgroups("");
             protectionGroupConfig.setHosts("");
             protectionGroupConfig.setTargets("");
             protectionGroupConfig.setVolumes("");
             protectionGroupConfig.setSource("");
             
            
             store.insert(protectionGroupConfig);
             
             
         		//UcsdCmdbUtils cmdb=new UcsdCmdbUtils();
              UcsdCmdbUtils.updateRecord("FlashArray ProtectionGroup", description, 1, context.getUserId(), protectionGroupName,description);
             
             
          
          
            
        }


    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[2];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Protection Group Identity");
   		ops[1] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_PROTECTIONGROUP_NAME,
   				PureConstants.PURE_PROTECTIONGROUP_LIST_TABLE_NAME,
   				"ProtectionGroup Name");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new CreateProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_CREATE_PROTECTIONGROUP_TASK;
	}

}