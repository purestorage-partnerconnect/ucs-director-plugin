package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.HostConnectionInventoryConfig;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import java.util.List;

public class HostConnectionReportImpl implements TabularReportGeneratorIf
{
    static Logger logger = Logger.getLogger(HostConnectionReportImpl.class);

    @Override
    public TabularReport getTabularReportReport(ReportRegistryEntry entry, ReportContext context) throws Exception
    {
        logger.info("Entering HCReportImpl.getTabularReportReport" );
        logger.info("ReportContext.getId()=" + context.getId());
        String accountName;
        if(context.getId().contains(";"))   //Checking the Context 
        {
        	 String[] parts = context.getId().split(";");
             accountName = parts[0];
           	
        }
        else
        {
           accountName = context.getId();
        }
        TabularReport report = new TabularReport();
        report.setGeneratedTime(System.currentTimeMillis());
        report.setReportName(entry.getReportLabel());
        report.setContext(context);

        TabularReportInternalModel model = new TabularReportInternalModel();
        model.addTextColumn("Id", "Id",true);
        model.addTextColumn("Account Name", "Account Name");
        model.addTextColumn("Host Name", "Name of Host");
        model.addTextColumn("Initiator WWPN", "Initiator WWPN detail");
		
		model.addTextColumn("Initiator IQN", "Initiator IQN detail");
		model.addTextColumn("Connectivity", "Connectivity detail");
		model.addTextColumn("Target Interface(s)", "Target Interface(s) detail");
		
		model.addTextColumn("Target WWPN(s)", "Target WWPN(s) detail",true);
		model.addTextColumn("Target IQN(s)", "Target IQN(s) detail",true);
		model.addTextColumn("Initiator Portal", "Initiator Portal detail",true);
		model.addTextColumn("Target Portal", "Target Portal detail",true);
		
        
        model.completedHeader();

        if (accountName != null && accountName.length() > 0)
        {
        	 List<HostConnectionInventoryConfig> hosts= PureUtils.getAllPureHostConnections();
             for (HostConnectionInventoryConfig host: hosts)
             {
             	 if (accountName.equalsIgnoreCase(host.getAccountName()))
                  {
             		
             		model.addTextValue(host.getId());
            		model.addTextValue(accountName);
                    model.addTextValue(host.getHostName());
                    model.addTextValue(host.getInitiatorWwpn());	
                    model.addTextValue(host.getInitiatorIqn());
                    model.addTextValue(host.getConnectivity());
                    
                    model.addTextValue(host.getTargetInterfaces());
                    model.addTextValue(host.getTargetWwpn());
                    model.addTextValue(host.getTargetIqn());
                    model.addTextValue(host.getIniatorPortal());
        			
        			model.addTextValue(host.getTargetPortal());
        			model.completedRow();
            		
            	}
            	            	
            }
                    
    }

        model.updateReport(report);
        return report;
    }
    
}