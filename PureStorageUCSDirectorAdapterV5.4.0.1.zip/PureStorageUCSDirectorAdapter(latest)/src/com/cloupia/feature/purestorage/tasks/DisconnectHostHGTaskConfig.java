package com.cloupia.feature.purestorage.tasks;

public class DisconnectHostHGTaskConfig {

}
