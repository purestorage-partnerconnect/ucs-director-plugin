package com.cloupia.feature.purestorage.accounts;

	
	import java.util.List;

	import com.cisco.cuic.api.client.JSON;
	import com.cloupia.fw.objstore.ObjStore;
	import com.cloupia.fw.objstore.ObjStoreHelper;
	import com.cloupia.lib.cIaaS.network.model.DeviceCredential;
	import com.cloupia.lib.connector.account.AbstractInfraAccount;
	import com.cloupia.lib.connector.account.AccountUtil;
	import com.cloupia.lib.connector.account.PhysicalInfraAccount;
	import com.cloupia.model.cIM.FormFieldDefinition;
	import com.cloupia.model.cIM.InfraAccount;
	import com.cloupia.service.cIM.inframgr.collector.view2.ConnectorCredential;
	import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.purestorage.rest.protectiongroup.PureArrayTarget;

import javax.jdo.annotations.PersistenceCapable;
	import javax.jdo.annotations.Persistent;

	import org.apache.log4j.Logger;

	@PersistenceCapable(detachable = "true", table = "ConnectionArray_Inventory_Configg")
 public class ConnectionArrayInventoryConfig {
	    static Logger logger = Logger.getLogger(ConnectionArrayInventoryConfig.class);

	    // ManagementAddress
	    @Persistent
	    private String id;
	    
	    public String getId()
	    {
	        return id;
	    }

	    public void setId(String id)
	    {
	        this.id = id;
	    }

	   
	   

		@Persistent
	     private String accountName;
		
		@Persistent
	     private String arrayName;

	    public void setAccountName(String accountName)
	    {
	        this.accountName = accountName;
	    }

	    
	    public String getAccountName()
	    {
	        return this.accountName;
	    }
	    
	    @Persistent
	     private String ManagementAddress;
	    
	    @Persistent
	     private String ReplicationAddress;
	    
	    @Persistent
	     private String Type;
	    
	    @Persistent
	     private String Version;
	    
	    


		public String getArrayName() {
			return arrayName;
		}

		public void setArrayName(String arrayName) {
			this.arrayName = arrayName;
		}

		public String getManagementAddress() {
			return ManagementAddress;
		}

		public void setManagementAddress(String managementAddress) {
			ManagementAddress = managementAddress;
		}

		public String getReplicationAddress() {
			return ReplicationAddress;
		}

		public void setReplicationAddress(String replicationAddress) {
			ReplicationAddress = replicationAddress;
		}

		public String getType() {
			return Type;
		}

		public void setType(String type) {
			Type = type;
		}

		public String getVersion() {
			return Version;
		}

		public void setVersion(String version) {
			Version = version;
		}

	}