package com.cloupia.feature.purestorage.actions.forms;

import javax.jdo.annotations.Persistent;

import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.ConnectionArrayTabularProvider;
import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class RemoveTargetProtectionGroupForm {
	

	@FormField(label = "targets ", help = "Use ',' to seperate target", mandatory = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table= ConnectionArrayTabularProvider.TABULAR_PROVIDER)
    @Persistent
   private String targets;

	public String getTargets() {
		return targets;
	}

	public void setTargets(String targets) {
		this.targets = targets;
	}

  



}
