package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class RemoveVolumeProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(RemoveVolumeProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	RemoveVolumeProtectionGroupTaskConfig config = (RemoveVolumeProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        final String volumeName = config.getVolumeName().split("@")[1];
        String protectionGroupName = config.getProtectionGroup().split("@")[1];
        
            

            try
            {
                CLIENT.protectionGroups().removeVolumes(protectionGroupName,Arrays.asList(volumeName));
            }
            catch(Exception e) {
                actionlogger.addError("There is no exsiting Volume " + volumeName + "in Protection GRoup.");
                throw e;
            }

           
            
             actionlogger.addInfo("Removing volume " + volumeName + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           /* context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "Scheduled Snapshot",
                    "Snapshots have been scheduled" + config.getAccountName(),
                    new DeleteScheduleSnapshotTask().getTaskName(), new DeleteScheduleSnapshotTaskConfig(config));
         */   String volIdentity =accountName+"@"+volumeName;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
         
         
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_VOLUME_IDENTITY, volIdentity);
        	actionlogger.addInfo("Volume Identity as Output is saved");
        	
        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
     	   
        	
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgConfig = store2.query(query3);
            logger.info("Volume Name :"+ pgConfig.get(0).getId());
            //pgconfig.get(0).getVolumes();
            String volumesList1= "";
            PureProtectionGroup protectiongroup=CLIENT.protectionGroups().get(protectionGroupName);
    		logger.info(" Volume :"+ volumesList1);
    		String volumesList2="";
    		if(protectiongroup.getVolumes().isEmpty())
    		{
    			pgConfig.get(0).setVolumes("");
    		}
    	else
    		{
    		
    	
    		List<String> volumeList = protectiongroup.getVolumes();
    		
    		logger.info(" Volume :"+ volumesList2);
    		for(String hos1 : volumeList)
    			{
    				if(volumesList2 == "")
    					{
    						volumesList2=hos1;
    					}else
    						{
    						volumesList2=volumesList2+","+hos1;
    						}
          }
          	pgConfig.get(0).setVolumes(volumesList2);
    		}
    				  
    	            store2.modifySingleObject("id == '" + accountName+"@"+protectionGroupName +"' && volumes == '" + volumesList2 + "'",  pgConfig.get(0));
    	            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
    	            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
    	            logger.info("Volume Name :"+ pgconfig1.get(0).getVolumes());
    		
    	           
        }


    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_VOLUME_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Volume Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new RemoveVolumeProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_REMOVE_VOLUME_PROTECTIONGROUP_TASK;
	}

}