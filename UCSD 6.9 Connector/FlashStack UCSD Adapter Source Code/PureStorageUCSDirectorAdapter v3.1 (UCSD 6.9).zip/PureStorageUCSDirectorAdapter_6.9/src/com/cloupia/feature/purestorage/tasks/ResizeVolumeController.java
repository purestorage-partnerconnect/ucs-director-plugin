package com.cloupia.feature.purestorage.tasks;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.lovs.VolumeTabularProvider;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.CellData;
import com.cloupia.model.cIM.FormFieldData;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.ReportingContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.forms.wizard.AbstractObjectUIController;
import com.cloupia.service.cIM.inframgr.forms.wizard.Page;
import com.cloupia.service.cIM.inframgr.forms.wizard.TabularFieldRegistry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;

public class ResizeVolumeController extends AbstractObjectUIController {

	private static Logger logger = Logger.getLogger(ResizeVolumeController.class);
	
	public void beforeMarshall(Page page, String id, ReportContext context, Object pojo)
		    throws Exception
		  {
			  
			  logger.info("############################################################");
		    ResizeVolumeTaskConfig config = (ResizeVolumeTaskConfig)pojo;
		    
		    
		    
				    String accountName=config.getAccountName();
				    logger.info("AccountName : " +accountName);
				   /* ReportContext fldContext = new ReportContext(90544, null, accountName+"@" + accountName );
				    page.setContext(id + ".accountName", fldContext);
			          page.setContext(id + ".volumeName", fldContext);*/
				    

				    if ((config.getAccountName() != null) && (config.getAccountName().length() > 0))
				    {
				    	 
				          String contextID =  accountName+"@" ;
				          ReportContext newContext = new ReportContext(ReportingContext.CONTEXT_ALL_PODS_PHYSICAL_STORAGE.getContext(), null, contextID);
				          page.setContext(id + ".accountName", newContext);
				          page.setContext(id + ".volumeName", newContext);
				          
				         /* DynReportContext context1 = ReportContextRegistry.getInstance().getContextByName(PureConstants.PURE_ACCOUNT_TYPE);
				          logger.info("****************ContextMapRule: context Id:" + context1.getId());
				          logger.info("ContextMapRule: ContextType:" + context1.getType());
				          //page.setContext(id + ".volumeName", );
				          
				          ReportContext accountContext = ReportingContext.CONTEXT_TYPE_EMC_XTREME_IO.getReportContext();
				          //context1.setId("accountName == '" + accountName + "'");
				          //page.setContext(id + ".targetIdentity", context1);
		*/		          
				    }  
			          
				    if(page.isValidateSet(id + ".accountName"))
				    {
				    
				    
				    if ((config.getAccountName() != null) && (config.getAccountName().length() > 0))
				    {
				    	 
				          String contextID =  accountName+"@" ;
				          ReportContext newContext = new ReportContext(ReportingContext.CONTEXT_ALL_PODS_PHYSICAL_STORAGE.getContext(), null, contextID);
				          page.setContext(id + ".accountName", newContext);
				          page.setContext(id + ".volumeName", newContext);
				          
				         /* DynReportContext context1 = ReportContextRegistry.getInstance().getContextByName(PureConstants.PURE_ACCOUNT_TYPE);
				          logger.info("****************ContextMapRule: context Id:" + context1.getId());
				          logger.info("ContextMapRule: ContextType:" + context1.getType());
				          //page.setContext(id + ".volumeName", );
				          
				          ReportContext accountContext = ReportingContext.CONTEXT_TYPE_EMC_XTREME_IO.getReportContext();
				          //context1.setId("accountName == '" + accountName + "'");
				          //page.setContext(id + ".targetIdentity", context1);
		*/		          
				    }  
		    }

		         
		       
		      
		    
		  }
		}
