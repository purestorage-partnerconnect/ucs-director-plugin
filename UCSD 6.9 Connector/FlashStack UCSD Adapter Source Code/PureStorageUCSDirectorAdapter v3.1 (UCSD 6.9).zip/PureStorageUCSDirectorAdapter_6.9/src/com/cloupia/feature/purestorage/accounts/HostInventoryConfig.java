package com.cloupia.feature.purestorage.accounts;

import javax.jdo.annotations.Column;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.tree.MoReference;

@XmlRootElement(name = "FlashArray_Host")
@PersistenceCapable(detachable = "true", table = "host_inventory_configg")
public class HostInventoryConfig implements TaskConfigIf{

    static Logger logger = Logger.getLogger(HostInventoryConfig.class);

    // ManagementAddress
    @Persistent
    private String id;
    
    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    @MoReference(path = "FlashArray.ID")
    @Persistent
    private String accountName;
    
    @MoReference(path = "FlashArray.ID.Host.ID", key = true)
    @Persistent
    private String host;
    
    @Persistent
    private String hostGroup;
    
    @Persistent
    private int volumes;
    
    @Persistent
    @Column(length = 1024000000, jdbcType = "CLOB")
    private String connectedVolumes;
    
    @Persistent
    private double provisionedSize;
    
    
    public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getHostGroup() {
		return hostGroup;
	}

	public void setHostGroup(String hostGroup) {
		this.hostGroup = hostGroup;
	}

	public int getVolumes() {
		return volumes;
	}

	public void setVolumes(int volumes) {
		this.volumes = volumes;
	}

	public String getConnectedVolumes() {
		return connectedVolumes;
	}

	public void setConnectedVolumes(String connectedVolumes) {
		this.connectedVolumes = connectedVolumes;
	}

	public double getProvisionedSize() {
		return provisionedSize;
	}

	public void setProvisionedSize(double provisionedSize) {
		this.provisionedSize = provisionedSize;
	}

	@Override
	public long getActionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getDisplayLabel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setActionId(long arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long getConfigEntryId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setConfigEntryId(long arg0) {
		// TODO Auto-generated method stub
		
	}

	
    
   
   
  }
