package com.cloupia.feature.purestorage.accounts;

import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.lib.connector.account.credential.CredentialParserIf;
import com.cloupia.lib.connector.account.credential.CredentialPolicyConfig;




/**
 * This is sample class for the Credential Policy Check implementation.
 * This is not mandatory to implement this class. Whenever the Crdential Policy check in enabled.
 * It is required to implement credential check of the Policy.
 */
public class FlashArrayAccountCredentialParser implements CredentialParserIf {

	private static Logger logger = Logger.getLogger(FlashArrayAccountCredentialParser.class);
	@Override
	public Object getCredentialsFromPolicy(String policyName, Object credentialObject)
			throws Exception {
		// TODO Auto-generated method stub
		// CredentialPolicyConfig config = getCredentialPolicyByName(policyName);
		 
		logger.info("######################## Policy Name " + policyName); 
		 
		 FlashArrayAccount credential = null;
          if (policyName!=null && !policyName.isEmpty()){
                         CredentialPolicyConfig config = getCredentialPolicyByName(policyName);
                         if (config!=null){
                                         credential = (FlashArrayAccount)credentialObject;
                                        credential.setUsername(config.getUserName());
                                        logger.info("######################## User Name " + config.getUserName()); 
                                        credential.setPassword(config.getPassword());
                                       
                         }
          }
          return credential;
	}
	
	
	
	  public static CredentialPolicyConfig getCredentialPolicyByName(String name)
	  {
	    try
	    {
	      ObjStore<CredentialPolicyConfig> store =  ObjStoreHelper.getStore(CredentialPolicyConfig.class);
	      List<CredentialPolicyConfig> list = store.query("name == '" + name + "'");
	      if ((list == null) || (list.isEmpty())) {
	        return null;
	      }
	      logger.info("######################## list" + list); 
	      return list.get(0);
	    }
	    catch (Exception e)
	    {
	      logger.info("Exception while getting the policy : " + e.getMessage());
	    }
	    return null;
	  }

}
