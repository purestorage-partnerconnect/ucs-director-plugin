package com.cloupia.feature.purestorage.tasks;


import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.feature.purestorage.lovs.VolumeGroupTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormController;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

@FormController(value = "com.cloupia.feature.purestorage.tasks.DeleteVolumeGroupController")
@XmlRootElement(name = "FlashArrayDeleteVolumeGroup")
@PersistenceCapable(detachable = "true", table = "psucs_delete_volumegroup_task_config")
public class DeleteVolumeGroupTaskConfig implements TaskConfigIf
{

    @FormField(label = "FlashArray Account", help = "FlashArray Account", mandatory=true,validate=true, type=FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = FlashArrayAccountsNameProvider.NAME)
    @UserInputField(type = PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME)
    @Persistent
    private String accountName;

    @MoReference(path = "FlashArray.ID.VolumeGroup.ID", key = true)
    @FormField(label = "VolumeGroup Name", help = "FlashArray VolumeGroup Name",  mandatory = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table=VolumeGroupTabularProvider.TABULAR_PROVIDER)
    @UserInputField(type = PureConstants.PURE_VOLUMEGROUP_TABLE_NAME)
    @Persistent
    private String volumeGroupName;

    
    
    @Persistent
    private long configEntryId;

    @Persistent
    private long actionId;


    @Override
    public long getActionId(){ return actionId;}

    @Override
    public long getConfigEntryId(){return configEntryId;}

 

    @Override
	public void setActionId(long arg0) {
		this.actionId = arg0;

	}

	@Override
	public void setConfigEntryId(long arg0) {
		this.configEntryId = arg0;

	}

    public DeleteVolumeGroupTaskConfig(){};

    public DeleteVolumeGroupTaskConfig(NewVolumeGroupTaskConfig config)
    {
        this.accountName = config.getAccountName();
        this.volumeGroupName = config.getVolumeGroupName();
        
    }

    @Override
	public String getDisplayLabel()
    {
        return PureConstants.TASK_NAME_DELETE_VOLUMEGROUP;
    }

    public String getAccountName()
    {
        return accountName;
    }
    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

	public String getVolumeGroupName() {
		return volumeGroupName;
	}

	public void setVolumeGroupName(String volumeGroupName) {
		this.volumeGroupName = volumeGroupName;
	}

	
   


}
