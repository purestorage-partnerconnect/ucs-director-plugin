
package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureArrayTarget;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class RemoveTargetProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(RemoveTargetProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	RemoveTargetProtectionGroupTaskConfig config = (RemoveTargetProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        final String targets = config.getTargets().split("@")[1];
        String protectionGroupName = config.getProtectionGroup().split("@")[1];
        
            

            try
            {
                CLIENT.protectionGroups().removeTargets(protectionGroupName, Arrays.asList(targets));
            }
            catch(Exception e) {
                actionlogger.addError("There is no exsiting Target " + targets + "in Protection GRoup.");
                throw e;
            }

           
            
             actionlogger.addInfo("Removing targets " + targets + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           /* context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "Scheduled Snapshot",
                    "Snapshots have been scheduled" + config.getAccountName(),
                    new DeleteScheduleSnapshotTask().getTaskName(), new DeleteScheduleSnapshotTaskConfig(config));
         */   String tarIdentity =accountName+"@"+targets;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_CONNECTIONARRAY_IDENTITY, tarIdentity);
        	actionlogger.addInfo("Target Identity as Output is saved");
        	
        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
        	   
        	
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgConfig = store2.query(query3);
            actionlogger.addInfo("Targets :"+ pgConfig.get(0).getId());
            //pgconfig.get(0).getHosts();
            String targetList1= "";
            PureProtectionGroup protectiongroup=CLIENT.protectionGroups().get(protectionGroupName);
    		logger.info(" Target :"+ targetList1);
    		
    		String targetList2="";
    		if(protectiongroup.getTargets().isEmpty())
    		{
    			pgConfig.get(0).setTargets("");
    		}
    	else
    		{
    		
    	
    		List<PureArrayTarget> targetList = protectiongroup.getTargets();
    		
    		logger.info(" Target :"+ targetList2);
    		for(PureArrayTarget hos1 : targetList)
    			{
    				if(targetList2 == "")
    					{
    						targetList2=hos1.getArrayName();
    					}else
    						{
    						targetList2=targetList2+","+hos1.getArrayName();
    						}
          }
          	pgConfig.get(0).setTargets(targetList2);
    		}		  
    	            store2.modifySingleObject("id == '" + accountName+"@"+protectionGroupName +"' && targets == '" + targetList2+ "'" ,  pgConfig.get(0));
    	            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
    	            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
    	            actionlogger.addInfo("target :"+ pgconfig1.get(0).getTargets());
    		
    	           
        }


    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_CONNECTIONARRAY_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"target Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new RemoveTargetProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_REMOVE_CONNECTIONARRAY_PROTECTIONGROUP_TASK;
	}

}