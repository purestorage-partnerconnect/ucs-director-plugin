package com.cloupia.feature.purestorage.accounts;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.FormLOVPair;
import com.cloupia.service.cIM.inframgr.ScheduleTask;

public class FlashArrayAccountCleanupTask implements ScheduleTask {
	private static Logger logger = Logger.getLogger(FlashArrayAccountCleanupTask.class);

	public static final String displayLabel = "FlashArray Account Cleanup Task";
	
	@Override
	public void execute(long lastExecuted) throws Exception {
		// TODO Auto-generated method stub
		Set<String> existingAccounts = getExistingAccountNames();
		Set<String> allKnownNimbleAccounts = getAllNimbleAccountNames();
		
		if (existingAccounts == null || existingAccounts.isEmpty()) {
		      return;
		}
		
		for(String accountName : allKnownNimbleAccounts){
			try{
				if(!existingAccounts.contains(accountName)){
			          Thread.sleep(1000L);
			          
			          PhysicalInfraAccount acc = AccountUtil.getAccountByName(accountName);
			          if (acc == null)
			          {
			        	logger.info("Deleting account data");
			        	PureUtils.deleteFlashArrayAccountData(accountName);
			          }
				}
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}

	private Set<String> getExistingAccountNames() {
		// TODO Auto-generated method stub
		Set<String> set = new HashSet<String>();
		try {
			List<PhysicalInfraAccount> existingAccounts = AccountUtil.getAccountByType(PureConstants.PURE_ACCOUNT_TYPE);
			if(existingAccounts != null && !existingAccounts.isEmpty()){
				for(PhysicalInfraAccount account : existingAccounts){
					set.add(account.getAccountName());
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("Getting exsting account names: "+set);
		return set;
	}

	private Set<String> getAllNimbleAccountNames() {
		// TODO Auto-generated method stub
		Set<String> set = new HashSet<String>();
		
		try
	    {
	      ObjStore<VolumeInventoryConfig> store = ObjStoreHelper.getStore(VolumeInventoryConfig.class);
	      List<Object> list = store.querySelectColumn(null, "distinct accountName");
	      if (list != null) {
	        for (Object obj : list) {
	          if (obj != null) {
	            set.add((String)obj);
	          }
	        }
	      }
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	    }
		
		try
	    {
	      ObjStore<HostInventoryConfig> store = ObjStoreHelper.getStore(HostInventoryConfig.class);
	      List<Object> list = store.querySelectColumn(null, "distinct accountName");
	      if (list != null) {
	        for (Object obj : list) {
	          if (obj != null) {
	            set.add((String)obj);
	          }
	        }
	      }
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	    }
		
		try
	    {
	      ObjStore<HostGroupInventoryConfig> store = ObjStoreHelper.getStore(HostGroupInventoryConfig.class);
	      List<Object> list = store.querySelectColumn(null, "distinct accountName");
	      if (list != null) {
	        for (Object obj : list) {
	          if (obj != null) {
	            set.add((String)obj);
	          }
	        }
	      }
	    }
	    catch (Exception e)
	    {
	      e.printStackTrace();
	    }
		
		logger.info("Getting known account names: "+set);
		return set;
	}

	@Override
	public long getFrequency() {
		// TODO Auto-generated method stub
		return ScheduleTask.FREQUENCY_HOURLY;
	}

	@Override
	public FormLOVPair[] getFrequencyHoursLov() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FormLOVPair[] getFrequencyMinsLov() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTaskExecutionMode() {
		// TODO Auto-generated method stub
		return ScheduleTask.EXECUTION_MODE_JOBMGR;
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return displayLabel;
	}

	@Override
	public boolean isValid() {
		// TODO Auto-generated method stub
		return true;
	}

}
