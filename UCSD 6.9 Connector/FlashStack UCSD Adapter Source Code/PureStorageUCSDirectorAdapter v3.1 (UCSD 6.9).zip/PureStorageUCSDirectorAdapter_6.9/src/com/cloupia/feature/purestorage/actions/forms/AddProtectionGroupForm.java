package com.cloupia.feature.purestorage.actions.forms;

import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class AddProtectionGroupForm {
	

	@FormField(label = "ProtectionGroup Name", help = "FlashArray ProtectionGroup Name", mandatory = true)
    private String pgName;

    

	public String getProtectionGroupName() {
		return pgName;
	}

	public void setProtectionGroupName(String pgName) {
		this.pgName = pgName;
	}

	

}
