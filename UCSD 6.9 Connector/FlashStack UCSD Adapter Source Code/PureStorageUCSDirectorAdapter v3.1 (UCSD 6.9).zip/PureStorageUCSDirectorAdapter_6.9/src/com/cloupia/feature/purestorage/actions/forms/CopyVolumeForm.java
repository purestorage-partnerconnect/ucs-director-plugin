package com.cloupia.feature.purestorage.actions.forms;

import com.cloupia.feature.purestorage.lovs.VolumeSizeUnitProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class CopyVolumeForm {
	
    
    @FormField(label = "Volume PreName", help = "FlashArray VolumePreName", mandatory = true)

	private String volumePreName;
    
    
	
	
	public String getVolumePreName() {
		return volumePreName;
	}

	public void setVolumePreName(String volumePreName) {
		this.volumePreName = volumePreName;
	}

	

}
