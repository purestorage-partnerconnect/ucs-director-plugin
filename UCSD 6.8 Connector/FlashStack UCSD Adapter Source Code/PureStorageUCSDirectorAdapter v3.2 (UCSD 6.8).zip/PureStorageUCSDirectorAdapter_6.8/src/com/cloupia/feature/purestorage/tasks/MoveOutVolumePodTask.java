package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;
import com.purestorage.rest.hostgroup.PureHostGroupConnection;
import com.purestorage.rest.pod.PurePodSpace;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;


public class MoveOutVolumePodTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(MoveOutVolumePodTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	MoveOutVolumePodTaskConfig config = (MoveOutVolumePodTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking PodTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount,"1.14");


        String podName = config.getPodName().split("@")[1];
       //String volumeName = config.getVolumeName().split("@")[1];
        String volumeName = config.getVolumeName();
        if(volumeName.contains("@"))
        {
     	   volumeName = config.getVolumeName().split("@")[1];
        }
                 try
                 {
                	 CLIENT.volumes().removeVolume(volumeName);
                    actionlogger.addInfo("Adding Volume "+volumeName+" pod " + podName);
                    ObjStore<PodInventoryConfig> store2 = ObjStoreHelper.getStore(PodInventoryConfig.class);
             	   
                    String query3 = "id == '" + accountName+"@"+podName + "'";
                    List<PodInventoryConfig> podConfig = store2.query(query3);
                    actionlogger.addInfo("Pod Id :"+ podConfig.get(0).getId());
                    
                    PurePodSpace space=CLIENT.pods().listNamedPodSpace(podName).get(0);
                    
                    long vol= space.getVolumes()/(1024*1024*1024);
                    long snap= space.getSnapshots()/(1024*1024*1024);
                    long total =  space.getTotal()/(1024*1024*1024);
                	 double red = space.getData_reduction()/(1024*1024*1024);
                	 
                	podConfig.get(0).setVolumes(vol);
                	podConfig.get(0).setSnapshots(snap);
                	podConfig.get(0).setTotal(total);
                	podConfig.get(0).setReduction(red);
                
                	
                     store2.modifySingleObject("volumes == " + vol + " && snapshots == " + snap +" && total == " + total +" && reduction == " + red,  podConfig.get(0));
                     
                    
                    actionlogger.addInfo("Moved Volumed in Inventory " );
                }
            
            catch (PureException e)
            {
                actionlogger.addError("Error happens while moving volume in pod : " + podName + "Exception: " + e.getMessage());
                throw e;
            }
          
        
        
    	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY, accountName+"@"+podName);
    	actionlogger.addInfo("Pod Identity as Output is saved");
    	
    	String description="FlashArray Pod is Modified. Details are : Account Name = "+config.getAccountName()+" , Pod Name = "+ podName;
        
       // UcsdCmdbUtils.updateRecord("FlashArray Pod", description, 2, context.getUserId(), podName,description);
        
       // context.getChangeTracker().resourceAdded("FlashArray Pod : MoveOutVolumed",accountName+"@"+podName, podName, description);
    	context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "MovedVolumesToPod",
                "Volumes has been moved out from pod " + config.getAccountName(),
                new MoveVolumePodTask().getTaskName(), new MoveVolumePodTaskConfig(config));
    
    }

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Pod Identity(s)");
   		return ops;
    }


   
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new MoveOutVolumePodTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_MOVE_VOLUME_OUT_POD;
	}

}
