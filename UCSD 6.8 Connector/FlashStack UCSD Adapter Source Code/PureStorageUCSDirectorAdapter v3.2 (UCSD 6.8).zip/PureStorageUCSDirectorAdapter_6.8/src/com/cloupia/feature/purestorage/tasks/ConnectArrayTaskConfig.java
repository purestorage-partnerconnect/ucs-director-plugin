package com.cloupia.feature.purestorage.tasks;


import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.ArrayTypeProvider;
import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.feature.purestorage.lovs.PodTabularProvider;
import com.cloupia.feature.purestorage.lovs.VolumeTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FlashArrayConnectArray")
@PersistenceCapable(detachable = "true", table = "psucs_connect_array_task_config")
public class ConnectArrayTaskConfig implements TaskConfigIf
{

    @FormField(label = "FlashArray Account", help = "FlashArray Account", mandatory=true, type=FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = FlashArrayAccountsNameProvider.NAME)
    @UserInputField(type = PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME)
    @Persistent
    private String accountName;

    @MoReference(path = "FlashArray.ID.ManagementAddress.ID", key = true)
    @FormField(label = "Management Address",help = "IP Address", mandatory = true )
    @UserInputField(type = WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String managementAddress;

   // @MoReference(path = "FlashArray.ID.Volume.ID", key = true)
    @FormField(label = "Type",  help = "Letters", mandatory=true, type=FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = ArrayTypeProvider.NAME)
    @UserInputField(type = PureConstants.PURE_ARRAY_TYPE_LOV_NAME)
    @Persistent
    private String type;
    
    @FormField(label = "Connection Key",  help = "Letters", mandatory = true )
    @UserInputField(type = WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String connectionKey;
    
    @FormField(label = "Replication Address",help = "IP Address" )
    @UserInputField(type = WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String replicationAddress;
    
    @Persistent
    private long configEntryId;

    @Persistent
    private long actionId;


    @Override
    public long getActionId(){ return actionId;}

    @Override
    public long getConfigEntryId(){return configEntryId;}

 

    @Override
	public void setActionId(long arg0) {
		this.actionId = arg0;

	}

	@Override
	public void setConfigEntryId(long arg0) {
		this.configEntryId = arg0;

	}

    public ConnectArrayTaskConfig(){};

   

    @Override
	public String getDisplayLabel()
    {
        return PureConstants.TASK_NAME_CONNECT_ARRAY;
    }

    public String getAccountName()
    {
        return accountName;
    }
    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

	public String getManagementAddress() {
		return managementAddress;
	}

	public void setManagementAddress(String managementAddress) {
		this.managementAddress = managementAddress;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getConnectionKey() {
		return connectionKey;
	}

	public void setConnectionKey(String connectionKey) {
		this.connectionKey = connectionKey;
	}

	public String getReplicationAddress() {
		return replicationAddress;
	}

	public void setReplicationAddress(String replicationAddress) {
		this.replicationAddress = replicationAddress;
	}

	
	
   


}
