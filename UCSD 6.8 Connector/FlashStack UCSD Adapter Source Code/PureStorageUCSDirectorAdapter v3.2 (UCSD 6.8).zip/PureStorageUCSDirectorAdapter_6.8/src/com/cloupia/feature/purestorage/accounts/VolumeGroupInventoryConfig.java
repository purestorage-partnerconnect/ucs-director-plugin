package com.cloupia.feature.purestorage.accounts;

import javax.jdo.annotations.Column;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.tree.MoReference;


@XmlRootElement(name = "FlashArray_VolumeGroup")

@PersistenceCapable(detachable = "true", table = "volumegroup_inventory_config")
public class VolumeGroupInventoryConfig implements TaskConfigIf{


    static Logger logger = Logger.getLogger(VolumeGroupInventoryConfig.class);

    // ManagementAddress
    @Persistent
    private String id;
    
    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    @MoReference(path = "FlashArray.ID")
    @Persistent
    private String accountName;
    
    @MoReference(path = "FlashArray.ID.VolumeGroup.ID", key = true)
    @Persistent
    private String volumeGroupName;
    
    @Persistent
    private int noVolume;
    
    
    
    @Persistent
    private long snapshots;
    
    @Persistent
    private long volumes;
    
	@Persistent
    private double total;
	
	
	@Persistent
    private double reduction;
	
	

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}


	public long getVolumes() {
		return volumes;
	}

	public void setVolumes(Long long1) {
		this.volumes = long1;
	}

	

	
	

	

	public String getVolumeGroupName() {
		return volumeGroupName;
	}

	public void setVolumeGroupName(String volumeGroupName) {
		this.volumeGroupName = volumeGroupName;
	}

	public int getNoVolume() {
		return noVolume;
	}

	public void setNoVolume(int noVolume) {
		this.noVolume = noVolume;
	}

	public void setVolumes(long volumes) {
		this.volumes = volumes;
	}

	public long getSnapshots() {
		return snapshots;
	}

	public void setSnapshots(long snapshots) {
		this.snapshots = snapshots;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getReduction() {
		return reduction;
	}

	public void setReduction(double reduction) {
		this.reduction = reduction;
	}

	@Override
	public long getActionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getDisplayLabel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setActionId(long arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long getConfigEntryId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setConfigEntryId(long arg0) {
		// TODO Auto-generated method stub
		
	}
    
    
   
   
  }
