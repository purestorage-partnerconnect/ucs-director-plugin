package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;
import com.purestorage.rest.hostgroup.PureHostGroupConnection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;


public class DeletePodTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(DeletePodTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	DeletePodTaskConfig config = (DeletePodTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking PodTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount,"1.14");


        
        String podName = config.getPodName();
        if(podName.contains("@"))
        {
        	podName = config.getPodName().split("@")[1];
        }
       
                 try
                 {
                	 CLIENT.pods().destroy(podName);
                    actionlogger.addInfo("deleting pod" + podName);
                    ObjStore<PodInventoryConfig> store2 = ObjStoreHelper.getStore(PodInventoryConfig.class);
             	   
                    String query3 = "id == '" + accountName+"@"+podName + "'";
                    List<PodInventoryConfig> hconfig = store2.query(query3);
                    actionlogger.addInfo("Pod Id :"+ hconfig.get(0).getId());
                
                    long s = store2.delete(query3);
                    actionlogger.addInfo("Deleted in Inventory :" + s);
                }
            
            catch (PureException e)
            {
                actionlogger.addError("Error happens while deleting pod " + podName + "Exception: " + e.getMessage());
                throw e;
            }
          
        
        
    	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY, accountName+"@"+podName);
    	actionlogger.addInfo("Pod Identity as Output is saved");
    	
    	String description="FlashArray Pod is Deleted. Details are : Account Name = "+config.getAccountName()+" , Pod Name = "+ podName;
        
        UcsdCmdbUtils.updateRecord("FlashArray Pod", description, 2, context.getUserId(), podName,description);
        
        context.getChangeTracker().resourceAdded("FlashArray Pod : Deleted",accountName+"@"+podName, podName, description);
        context.getChangeTracker().undoableResourceDeleted("FlashArray HostGroup", accountName+"@"+podName, podName, description,
                new NewPodTask().getTaskName(), new NewPodTaskConfig(config));
    
    }

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Pod Identity(s)");
   		return ops;
    }


   
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new DeletePodTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_DELETE_POD;
	}

}
