package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.host.PureHostConnection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class HostGroupVolumeReportImpl implements TabularReportGeneratorIf
{
    static Logger logger = Logger.getLogger(HostGroupVolumeReportImpl.class);

    @Override
    public TabularReport getTabularReportReport(ReportRegistryEntry entry, ReportContext context) throws Exception
    {
        logger.info("Entering VolumeReportImpl.getTabularReportReport" );
        logger.info("ReportContext.getId()=" + context.getId());
        String accountName = "";
        String hName = "";
        if(context.getId().contains("@"))   //Checking the Context 
        {
        	String[] parts = context.getId().split("@",2);
            accountName = parts[0];
            hName = parts[1];
           	
        }
        else
        {
        	logger.error("Error in Report Generation ..Wrong Conext" + context);
            
        }
        
        logger.info("Name = " + hName);
        TabularReport report = new TabularReport();
        report.setGeneratedTime(System.currentTimeMillis());
        report.setReportName(entry.getReportLabel());
        report.setContext(context);

        TabularReportInternalModel model = new TabularReportInternalModel();
        model.addTextColumn("Id", "Id",true);
        model.addTextColumn("Account Name", "Name of Account");
        model.addTextColumn("Volume Name", "Name of Volume");
        model.addDoubleColumn("Size (GB)", "Size of Volume");
        model.addTextColumn("Source", "Source of Volume");
        model.addTimeColumn("Creation","Creation Time of Volume");
        model.completedHeader();

        if (accountName != null && accountName.length() > 0)
        {
//            FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
//            PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
//            List<PureVolume> volumes =  CLIENT.volumes().list();
            List<VolumeInventoryConfig> volumes= PureUtils.getAllPureVolumes();
            List<HostGroupInventoryConfig> hosts= PureUtils.getAllPureHostGroup();
            for (HostGroupInventoryConfig host: hosts)
            {
            	if(hName.equalsIgnoreCase(host.getHostGroupName()))
            	{
            		List<String> vlist = new ArrayList<String>(Arrays.asList(host.getConnectedVolumes().split(",")));
            	
            		
			            for (VolumeInventoryConfig volume: volumes)
			            {
			            	if(vlist.contains(volume.getVolumeName()))
			            	{
			            
				            	 if (accountName.equalsIgnoreCase(volume.getAccountName()))
				                 {
				            		 
					            	model.addTextValue(volume.getId());
					            	model.addTextValue(accountName);
					                model.addTextValue(volume.getVolumeName());
					                model.addDoubleValue(volume.getSize());
					                model.addTextValue(volume.getSource());
					                model.addTimeValue(volume.getCreation());
					                model.completedRow();
					                
				                 }
			            	}
			
			            }
            	}
            }
        }

        model.updateReport(report);
        return report;
    }
}
    