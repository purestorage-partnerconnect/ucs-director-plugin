package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import java.util.List;

public class PodReportImpl implements TabularReportGeneratorIf
{
    static Logger logger = Logger.getLogger(PodReportImpl.class);

    @Override
    public TabularReport getTabularReportReport(ReportRegistryEntry entry, ReportContext context) throws Exception
    {
        logger.info("Entering PodReportImpl.getTabularReportReport" );
        logger.info("ReportContext.getId()=" + context.getId()+context);
        String accountName;
        if(context.getId().contains(";"))   //Checking the Context 
        {
        	 String[] parts = context.getId().split(";");
             accountName = parts[0];
           	
        }
        else
        {
           accountName = context.getId();
        }
        TabularReport report = new TabularReport();
        report.setGeneratedTime(System.currentTimeMillis());
        report.setReportName(entry.getReportLabel());
        report.setContext(context);

        TabularReportInternalModel model = new TabularReportInternalModel();
       
        model.addTextColumn("Id", "Id",true);
        model.addTextColumn("Account Name", "Name of Account ");
        model.addTextColumn("Pods", "Name of Pod");
        model.addTextColumn("Array", "Array");
        model.addLongNumberColumn("Snapshots (GB)", "Snapshots");
        model.addLongNumberColumn("Volumes (GB)", "Volumes");
        model.addDoubleColumn("Total (GB)", "Total");
        model.addDoubleColumn("Reduction", "Reduction");
        model.completedHeader();

        
        if (accountName != null && accountName.length() > 0 )
        {
//            FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
//            PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
//            List<PurePod> pods =  CLIENT.pods().list();
//            for (PurePod pod: pods)
        	List<PodInventoryConfig> pods= PureUtils.getAllPurePod();
             for (PodInventoryConfig pod: pods)
             {
            	 if (accountName.equalsIgnoreCase(pod.getAccountName()))
                 {
              
            	model.addTextValue(pod.getId());
            	model.addTextValue(accountName);
                model.addTextValue(pod.getPodName()); // Name
                model.addTextValue(pod.getArray()); //PodGroup
                model.addLongNumberValue(pod.getSnapshots()); // Number of volumes
                model.addLongNumberValue(pod.getVolumes()); // Number of volumes
                model.addDoubleValue(pod.getTotal()); // Number of volumes
                model.addDoubleValue(pod.getReduction()); // Number of volumes
              
                model.completedRow();
                 }
            }
        }

        model.updateReport(report);
        return report;
    }
}