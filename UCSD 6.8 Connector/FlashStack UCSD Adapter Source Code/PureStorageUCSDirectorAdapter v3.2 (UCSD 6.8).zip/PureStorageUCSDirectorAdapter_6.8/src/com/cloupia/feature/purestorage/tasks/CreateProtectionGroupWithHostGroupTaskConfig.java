package com.cloupia.feature.purestorage.tasks;


import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.HostGroupTabularProvider;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.TimeClockProvider;
import com.cloupia.feature.purestorage.lovs.TimeUnitProvider;
import com.cloupia.feature.purestorage.lovs.VolumeTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormController;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;

@FormController(value = "com.cloupia.feature.purestorage.tasks.CreateProtectionGroupWithHostGroupController")
@XmlRootElement(name = "FlashArrayCreateProtectionGroupWithHostGroup")
@PersistenceCapable(detachable = "true", table = "psucs_create_hostgrouponprotectiongroup_config")
public class CreateProtectionGroupWithHostGroupTaskConfig implements TaskConfigIf
{

    @FormField(label = "FlashArray Account", help = "FlashArray Account", mandatory = true,validate=true, type = FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = FlashArrayAccountsNameProvider.NAME)
    @UserInputField(type = PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME)
    @Persistent
    private String accountName;

     
    @MoReference(path = "FlashArray.ID.ProtectionGroup.ID", key = true)
    @FormField(label="Protection Group Name",help="Provide the Protection Group Name", mandatory=true)
    @UserInputField(type=WorkflowInputFieldTypeDeclaration.GENERIC_TEXT)
    @Persistent
    private String protectionGroup;

    @FormField(label = "HostGroup Name", help = "FlashArray HostGroup Name", mandatory = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table= HostGroupTabularProvider.TABULAR_PROVIDER)
    @UserInputField(type = PureConstants.PURE_HOSTGROUP_NAME)
    @Persistent
    private String hostGroupName;

    
    public String getProtectionGroup() {
		return protectionGroup;
	}

	public void setProtectionGroup(String protectionGroup) {
		this.protectionGroup = protectionGroup;
	}
	@Persistent
    private long configEntryId;

    public String getHostGroupName() {
		return hostGroupName;
	}

	public void setHostGroupName(String hostGroupName) {
		this.hostGroupName = hostGroupName;
	}
	@Persistent
    private long actionId;


    @Override
    public long getActionId(){ return actionId;}

    @Override
    public long getConfigEntryId(){return configEntryId;}

 

    @Override
	public void setActionId(long arg0) {
		this.actionId = arg0;

	}

	@Override
	public void setConfigEntryId(long arg0) {
		this.configEntryId = arg0;

	}


    public CreateProtectionGroupWithHostGroupTaskConfig(){}

    /*public AddVolumeProtectionGroupTaskConfig(DeleteScheduleSnapshotTaskConfig config)
    {
        this.accountName = config.getAccountName();
        this.volumeName = config.getVolumeName();
        //this.deleteScheduleSnapshotFlag = config.getDeleteScheduleSnapshotFlag();
    }*/

    public String getDisplayLabel()
    {
        return PureConstants.TASK_NAME_CREATE_PROTECTIONGROUPWITHHOSTGROUP_TASK;
    }

    public String getAccountName()
    {
        return accountName;
    }
    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }
  

}