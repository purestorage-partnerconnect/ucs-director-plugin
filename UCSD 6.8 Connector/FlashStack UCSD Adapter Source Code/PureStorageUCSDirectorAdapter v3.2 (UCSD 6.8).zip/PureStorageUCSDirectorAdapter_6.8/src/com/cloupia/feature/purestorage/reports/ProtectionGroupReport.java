package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.actions.AddHost;
import com.cloupia.feature.purestorage.actions.AddHostProtectionGroup;
import com.cloupia.feature.purestorage.actions.AddProtectionGroup;
import com.cloupia.feature.purestorage.actions.AddTargetProtectionGroup;
import com.cloupia.feature.purestorage.actions.AddVolume;
import com.cloupia.feature.purestorage.actions.AddVolumeProtectionGroup;
import com.cloupia.feature.purestorage.actions.ConnectVolumeHost;
import com.cloupia.feature.purestorage.actions.CopyVolume;
import com.cloupia.feature.purestorage.actions.DeleteHost;
import com.cloupia.feature.purestorage.actions.DeleteProtectionGroup;
import com.cloupia.feature.purestorage.actions.DestroyVolume;
import com.cloupia.feature.purestorage.actions.DisconnectVolumeHost;
import com.cloupia.feature.purestorage.actions.RemoveHostProtectionGroup;
import com.cloupia.feature.purestorage.actions.RemoveTargetProtectionGroup;
import com.cloupia.feature.purestorage.actions.RemoveVolumeProtectionGroup;
import com.cloupia.feature.purestorage.actions.RenameHost;
import com.cloupia.feature.purestorage.actions.ResizeVolume;
import com.cloupia.feature.purestorage.actions.ScheduleVolumeSnapshot;
import com.cloupia.feature.purestorage.constants.PureConstants;

import com.cloupia.model.cIM.DynReportContext;
import com.cloupia.model.cIM.ReportContextRegistry;
import com.cloupia.service.cIM.inframgr.reportengine.ContextMapRule;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReportAction;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReportWithActions;
import com.cloupia.service.cIM.inframgr.reports.simplified.actions.DrillDownAction;

public class ProtectionGroupReport extends CloupiaReportWithActions
{

    private static Logger logger = Logger.getLogger(ProtectionGroupReport.class);

    public ProtectionGroupReport()
    {
        super();
        this.setMgmtDisplayColumnIndex(2); 
        this.setMgmtColumnIndex(0);
    }

    @Override
    public CloupiaReportAction[] getActions()
    {
    	AddProtectionGroup createaction = new AddProtectionGroup();
    	DeleteProtectionGroup deleteaction = new DeleteProtectionGroup();
    	AddHostProtectionGroup addH = new AddHostProtectionGroup();
    	RemoveHostProtectionGroup removeH = new RemoveHostProtectionGroup();
    	AddVolumeProtectionGroup addV = new AddVolumeProtectionGroup();
    	RemoveVolumeProtectionGroup removeV = new RemoveVolumeProtectionGroup();
    	AddTargetProtectionGroup addT = new AddTargetProtectionGroup();
    	RemoveTargetProtectionGroup removeT = new RemoveTargetProtectionGroup();
    	DrillDownAction act=new DrillDownAction();
		CloupiaReportAction[] actions = new CloupiaReportAction[9];
		
		actions[0] = createaction;
		actions[1] = deleteaction;
		actions[2] = addH;
		actions[3] = removeH;
		actions[4] = addV;
		actions[5] = removeV;
		actions[6] = addT;
		actions[7] = removeT;
		actions[8] = act;
		
		
		
		return actions;
    	
    	
    }

    @Override
    public Class<?> getImplementationClass()
    {
        return ProtectionGroupReportImpl.class;
    }

    @Override
    public String getReportLabel()
    {
        return "Protection Groups";
    }

    @Override
    public String getReportName()
    {
        return "com.purestorage.flasharray.protectiongroup";
    }

    @Override
    public boolean isEasyReport()
    {
        return false;
    }

    @Override
    public boolean isLeafReport()
    {
        return false;
    }

    @Override
    public int getMenuID()
    {
        return PureConstants.PROTECTIONGROUP_MENU_LOCATION;
    }

    @Override
    public ContextMapRule[] getMapRules()
    {
        DynReportContext context = ReportContextRegistry.getInstance().getContextByName(PureConstants.PURE_ACCOUNT_TYPE);
        logger.info("ContextMapRule: context Id:" + context.getId());
        logger.info("ContextMapRule: ContextType:" + context.getType());
        ContextMapRule rule = new ContextMapRule();
        rule.setContextName(context.getId());
        rule.setContextType(context.getType());

        ContextMapRule[] rules = new ContextMapRule[1];
        rules[0] = rule;

        return rules;
    }
    
    @Override
   	public boolean showInSummary()
   	{
   		return false;
   	}

}