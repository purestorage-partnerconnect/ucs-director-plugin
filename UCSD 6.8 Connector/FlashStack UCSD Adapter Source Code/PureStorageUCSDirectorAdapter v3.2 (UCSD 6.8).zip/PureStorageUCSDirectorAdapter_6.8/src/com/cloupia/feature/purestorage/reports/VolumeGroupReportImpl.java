package com.cloupia.feature.purestorage.reports;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeGroupInventoryConfig;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import java.util.List;

public class VolumeGroupReportImpl implements TabularReportGeneratorIf
{
    static Logger logger = Logger.getLogger(VolumeGroupReportImpl.class);

    @Override
    public TabularReport getTabularReportReport(ReportRegistryEntry entry, ReportContext context) throws Exception
    {
        logger.info("Entering VolumeGroupReportImpl.getTabularReportReport" );
        logger.info("ReportContext.getId()=" + context.getId()+context);
        String accountName;
        if(context.getId().contains(";"))   //Checking the Context 
        {
        	 String[] parts = context.getId().split(";");
             accountName = parts[0];
           	
        }
        else
        {
           accountName = context.getId();
        }
        TabularReport report = new TabularReport();
        report.setGeneratedTime(System.currentTimeMillis());
        report.setReportName(entry.getReportLabel());
        report.setContext(context);

        TabularReportInternalModel model = new TabularReportInternalModel();
       
        model.addTextColumn("Id", "Id",true);
        model.addTextColumn("Account Name", "Name of Account ");
        model.addTextColumn("Volume Groups", "Name of Pod");
        model.addNumberColumn("No. Of Volumes", "No. Of Volumes");
        model.addLongNumberColumn("Snapshots (GB)", "Snapshots");
        model.addLongNumberColumn("Volumes (GB)", "Volumes");
        model.addDoubleColumn("Total (GB)", "Total");
        // model.addDoubleColumn("Reduction", "Reduction");
        model.completedHeader();

        
        if (accountName != null && accountName.length() > 0 )
        {
//            FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
//            PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
//            List<PurePod> pods =  CLIENT.pods().list();
//            for (PurePod pod: pods)
        	List<VolumeGroupInventoryConfig> vgs= PureUtils.getAllPureVolumeGroup();
             for (VolumeGroupInventoryConfig vg: vgs)
             {
            	 if (accountName.equalsIgnoreCase(vg.getAccountName()))
                 {
              
            	model.addTextValue(vg.getId());
            	model.addTextValue(accountName);
                model.addTextValue(vg.getVolumeGroupName()); 
                model.addNumberValue(vg.getNoVolume()); 
                model.addLongNumberValue(vg.getSnapshots()); 
                model.addLongNumberValue(vg.getVolumes()); 
                model.addDoubleValue(vg.getTotal()); 
               // model.addDoubleValue(pod.getReduction()); 
              
                model.completedRow();
                 }
            }
        }

        model.updateReport(report);
        return report;
    }
}