package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;
import com.purestorage.rest.pod.PurePod;
import com.purestorage.rest.pod.PurePodArray;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;


public class NewPodTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(NewPodTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	NewPodTaskConfig config = (NewPodTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking NewPodTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount,"1.14");
        
        PurePod pod;
        String podName=config.getPodName();
        try
        {
        	 pod=CLIENT.pods().create(podName);
        	
        	
       
        }catch(PureException e)
        {
        	actionlogger.addError(e.getMessage());
        	throw new Exception(e.getMessage());
        }
        
        if(pod.getName().equals(podName))
    	{
    		 ObjStore<PodInventoryConfig> store = ObjStoreHelper.getStore(PodInventoryConfig.class);
    		 
    		 PodInventoryConfig podConfig=new PodInventoryConfig();
    		 
    		 podConfig.setAccountName(accountName);
    		 podConfig.setId(accountName+"@"+podName);
    		 podConfig.setPodName(podName);
    		 String arrays="";
         	for(PurePodArray arr :pod.getArrays())
         		arrays= arrays+","+arr.getName();
         	
         	podConfig.setArray(arrays.substring(1, arrays.length()));
         	
         	store.insert(podConfig);
    	      
    	}
            actionlogger.addInfo("Successfully created pod " + podName +
                    " on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
           
            
            context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY, accountName+"@"+podName);
            context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_POD_NAME, accountName+"@"+podName);
        	
        	actionlogger.addInfo("Pod Identity as Output is saved");
        	
        	//UcsdCmdbUtils cmdb=new UcsdCmdbUtils();
            String description="FlashArray Pod is created. Details are : Account Name = "+config.getAccountName()+" , Pod Name = "+ podName;
            
            UcsdCmdbUtils.updateRecord("FlashArray Pod", description, 1, context.getUserId(), podName,description);
            
            //context.getChangeTracker().resourceAdded("FlashArray HostGroup", hostGroupIdentity, hostGroupPreName, description);
            context.getChangeTracker().undoableResourceAdded("FlashArray Pod : Created", accountName+"@"+podName, podName,description,
                    new DeletePodTask().getTaskName(), new DeletePodTaskConfig(config));

            
       
        
    }

  

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[2];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Pod Identity(s)");
   		ops[1] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_POD_NAME,
   				PureConstants.PURE_POD_TABLE_NAME,
   				"FlashArray Pod Name");
   		
   		
   		return ops;
    }

	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new NewPodTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_POD;
	}

}
