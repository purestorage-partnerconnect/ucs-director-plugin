package com.cloupia.feature.purestorage.lovs;


import com.cloupia.model.cIM.FormLOVPair;
import com.cloupia.service.cIM.inframgr.forms.wizard.LOVProviderIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;


public class ServerHostingProvider implements LOVProviderIf
{

    public static final String NAME = "mampu_server_hosting_provider";

    @Override
    public FormLOVPair[] getLOVs(WizardSession session)
    {
        FormLOVPair[] pairs = new FormLOVPair[4];
       
        pairs[0] = new FormLOVPair("Physical", "Physical");
        pairs[1] = new FormLOVPair("Virtual", "Virtual");
        

        return pairs;
    }

}
