package com.cloupia.feature.purestorage;


import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.accounts.AccountSystemTaskReport;
import com.cloupia.feature.purestorage.accounts.ConnectionArrayInventoryConfig;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccountCleanupTask;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccountCredentialParser;
import com.cloupia.feature.purestorage.lovs.ArrayTypeProvider;
import com.cloupia.feature.purestorage.lovs.ConnectionArrayTabularProvider;
import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.HostGroupTabularProvider;
import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.feature.purestorage.lovs.NetworkInterfaceListTabularProvider;
import com.cloupia.feature.purestorage.lovs.NetworkPortListTabularProvider;
import com.cloupia.feature.purestorage.lovs.PodTabularProvider;
import com.cloupia.feature.purestorage.lovs.PortIQNTabularProvider;
import com.cloupia.feature.purestorage.accounts.FlashArrayConvergedStackBuilder;
import com.cloupia.feature.purestorage.accounts.FlashArrayInventoryListener;
import com.cloupia.feature.purestorage.accounts.FlashArrayTestConnectionHandler;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.SnapshotInventoryConfig;
import com.cloupia.feature.purestorage.accounts.SubnetInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.accounts.FlashArrayInventoryItemHandler;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.reports.ArrayReport;
import com.cloupia.feature.purestorage.reports.ChildHostReport;
import com.cloupia.feature.purestorage.reports.FcPortsReport;
import com.cloupia.feature.purestorage.reports.HostConnectionReport;
import com.cloupia.feature.purestorage.reports.HostGroupReport;
import com.cloupia.feature.purestorage.reports.HostGroupVolumeReport;
import com.cloupia.feature.purestorage.reports.HostReport;
import com.cloupia.feature.purestorage.reports.HostVolumeReport;
import com.cloupia.feature.purestorage.reports.IqnPortsReport;
import com.cloupia.feature.purestorage.reports.NetworkReport;
import com.cloupia.feature.purestorage.reports.PodReport;
import com.cloupia.feature.purestorage.reports.ProtectionGroupHostGroupReport;
import com.cloupia.feature.purestorage.reports.ProtectionGroupHostReport;
import com.cloupia.feature.purestorage.reports.ProtectionGroupReport;
import com.cloupia.feature.purestorage.reports.ProtectionGroupVolumeReport;
import com.cloupia.feature.purestorage.reports.SnapshotReport;
import com.cloupia.feature.purestorage.reports.SpaceReport;
import com.cloupia.feature.purestorage.reports.VolumeGroupReport;
import com.cloupia.feature.purestorage.reports.VolumeReport;
import com.cloupia.feature.purestorage.summary.PureSummaryReport;
import com.cloupia.feature.purestorage.tasks.ConnectWWWNToHostTask;
import com.cloupia.feature.purestorage.tasks.ConnectWWWNToHostTaskConfig;
import com.cloupia.feature.purestorage.tasks.CreateProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.CreateProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.CreateProtectionGroupWithHostGroupTask;
import com.cloupia.feature.purestorage.tasks.CreateProtectionGroupWithHostGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.CreateVlanTask;
import com.cloupia.feature.purestorage.tasks.CreateVlanTaskConfig;
import com.cloupia.feature.purestorage.tasks.NewVolumeTask;
import com.cloupia.feature.purestorage.tasks.NewVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.RemoveHostProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.RemoveHostProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.RemoveTargetProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.RemoveTargetProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.RemoveVolumeProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.RemoveVolumeProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.NewHostTask;
import com.cloupia.feature.purestorage.tasks.NewHostTaskConfig;
import com.cloupia.feature.purestorage.tasks.NewPodTask;
import com.cloupia.feature.purestorage.tasks.NewVolumeGroupTask;
import com.cloupia.feature.purestorage.tasks.AddArrayPodTask;
import com.cloupia.feature.purestorage.tasks.AddHostProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.AddHostProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.AddTargetProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.AddTargetProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.AddVolumeProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.AddVolumeProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.CloneSnapshotTask;
import com.cloupia.feature.purestorage.tasks.CloneSnapshotTaskConfig;
import com.cloupia.feature.purestorage.tasks.CloneVolumeTask;
import com.cloupia.feature.purestorage.tasks.CloneVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.ConnectArrayTask;
import com.cloupia.feature.purestorage.tasks.ConnectHostToHGTask;
import com.cloupia.feature.purestorage.tasks.ConnectHostToHGTaskConfig;
import com.cloupia.feature.purestorage.tasks.ConnectHostVolumeTask;
import com.cloupia.feature.purestorage.tasks.ConnectHostVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.ResizeVolumeTask;
import com.cloupia.feature.purestorage.tasks.ResizeVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.NewHostGroupTask;
import com.cloupia.feature.purestorage.tasks.NewHostGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.ConnectVolumeToHGTask;
import com.cloupia.feature.purestorage.tasks.ConnectVolumeToHGTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeleteHostTask;
import com.cloupia.feature.purestorage.tasks.DeleteHostTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeletePodTask;
import com.cloupia.feature.purestorage.tasks.DeleteProtectionGroupTask;
import com.cloupia.feature.purestorage.tasks.DeleteProtectionGroupTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeleteHGSuffixRangeTask;
import com.cloupia.feature.purestorage.tasks.DeleteHGSuffixRangeTaskConfig;
import com.cloupia.feature.purestorage.tasks.DestroyVolumesTask;
import com.cloupia.feature.purestorage.tasks.DestroyVolumesTaskConfig;
import com.cloupia.feature.purestorage.tasks.DisconnectHostHGTask;
import com.cloupia.feature.purestorage.tasks.DisconnectHostHGTaskConfig;
import com.cloupia.feature.purestorage.tasks.ScheduleVolumeSnapshotTask;
import com.cloupia.feature.purestorage.tasks.ScheduleVolumeSnapshotTaskConfig;
import com.cloupia.feature.purestorage.tasks.RestoreVolumeTask;
import com.cloupia.feature.purestorage.tasks.RestoreVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeleteScheduleSnapshotTask;
import com.cloupia.feature.purestorage.tasks.DeleteScheduleSnapshotTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeleteVlanTask;
import com.cloupia.feature.purestorage.tasks.DeleteVlanTaskConfig;
import com.cloupia.feature.purestorage.tasks.DeleteVolumeGroupTask;
import com.cloupia.feature.purestorage.tasks.DestroySnapshotTask;
import com.cloupia.feature.purestorage.tasks.DestroySnapshotTaskConfig;
import com.cloupia.feature.purestorage.tasks.DisconnectVolumeHostTask;
import com.cloupia.feature.purestorage.tasks.DisconnectVolumeHostTaskConfig;
import com.cloupia.feature.purestorage.tasks.MoveOutVolumePodTask;
import com.cloupia.feature.purestorage.tasks.MoveOutVolumeVGTask;
import com.cloupia.feature.purestorage.tasks.MoveVolumePodTask;
import com.cloupia.feature.purestorage.tasks.MoveVolumeVGTask;
import com.cloupia.feature.purestorage.tasks.DisconnectVolumeHGTask;
import com.cloupia.feature.purestorage.tasks.DisconnectVolumeHGTaskConfig;
import com.cloupia.feature.purestorage.tasks.RollbackResizeVolumeTask;
import com.cloupia.feature.purestorage.tasks.RollbackResizeVolumeTaskConfig;
import com.cloupia.feature.purestorage.tasks.ScheduleReplicationTask;
import com.cloupia.feature.purestorage.lovs.PortTabularProvider;
import com.cloupia.feature.purestorage.lovs.ProtectionGroupTabularProvider;
import com.cloupia.feature.purestorage.lovs.SnapshotTabularProvider;
import com.cloupia.feature.purestorage.lovs.SubnetTabularProvider;
import com.cloupia.feature.purestorage.lovs.TimeUnitProvider;
import com.cloupia.feature.purestorage.lovs.VolumeGroupTabularProvider;
import com.cloupia.feature.purestorage.lovs.TimeClockProvider;
import com.cloupia.feature.purestorage.lovs.VolumeSizeUnitProvider;
import com.cloupia.feature.purestorage.lovs.VolumeTabularProvider;
import com.cloupia.lib.connector.account.AccountTypeEntry;
import com.cloupia.lib.connector.account.PhysicalAccountTypeManager;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.model.cIM.InfraAccountTypes;
import com.cloupia.model.cIM.ReportContextRegistry;
import com.cloupia.service.cIM.inframgr.AbstractCloupiaModule;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.CustomFeatureRegistry;
import com.cloupia.service.cIM.inframgr.SystemScheduler;
import com.cloupia.service.cIM.inframgr.collector.controller.CollectorFactory;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputTypeRegistry;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReport;
import com.cloupia.service.cIM.tree.MoParser;
import com.cloupia.service.cIM.tree.MoPointer;
import com.cloupia.service.cIM.tree.WFTaskRestAdaptor;

public class PureStorageModule extends AbstractCloupiaModule
{
    private static Logger logger = Logger.getLogger(PureStorageModule.class);

    @Override
    public AbstractTask[] getTasks()
    {

        AbstractTask[] tasks = new AbstractTask[43];

        tasks[0] = new DestroyVolumesTask();
        tasks[1] = new NewVolumeTask();
        tasks[2] = new NewHostTask();
        tasks[3] = new ConnectHostVolumeTask();
        tasks[4] = new ResizeVolumeTask();
        tasks[5] = new NewHostGroupTask();
        tasks[6] = new ConnectVolumeToHGTask();
        tasks[7] = new DeleteHostTask();
        tasks[8] = new DeleteHGSuffixRangeTask();
        tasks[9] = new RestoreVolumeTask();
        tasks[10] = new ScheduleVolumeSnapshotTask();
        tasks[11] = new DeleteScheduleSnapshotTask();
        tasks[12] = new DisconnectVolumeHostTask();
        tasks[13] = new DisconnectVolumeHGTask();
        tasks[14] = new RollbackResizeVolumeTask();
        tasks[15] = new ConnectWWWNToHostTask();
        tasks[16] = new ConnectHostToHGTask();
        tasks[17] = new CreateVlanTask();
        tasks[18] = new DeleteVlanTask();
        tasks[19] = new CloneVolumeTask();
        tasks[20] = new DisconnectHostHGTask();
        tasks[21] = new AddVolumeProtectionGroupTask();
        tasks[22] = new RemoveVolumeProtectionGroupTask();
        tasks[23] = new DestroySnapshotTask();
        tasks[24] = new CloneSnapshotTask();
        tasks[25] = new CreateProtectionGroupTask();
        tasks[26] = new DeleteProtectionGroupTask();
        tasks[27] = new CreateProtectionGroupWithHostGroupTask();
        tasks[28] = new AddHostProtectionGroupTask();
        tasks[29] = new RemoveHostProtectionGroupTask();
        tasks[30] = new AddTargetProtectionGroupTask();
        tasks[31] = new RemoveTargetProtectionGroupTask();
        tasks[32] = new ScheduleReplicationTask();
        tasks[33] = new NewPodTask();
        tasks[34]= new DeletePodTask();
        tasks[35] = new MoveVolumePodTask();
        tasks[36]= new MoveOutVolumePodTask();
        tasks[37]= new AddArrayPodTask();
        tasks[38]= new ConnectArrayTask();
        tasks[39]= new DeleteVolumeGroupTask();
        tasks[40]= new MoveOutVolumeVGTask();
        tasks[41]= new MoveVolumeVGTask();
        tasks[42]= new NewVolumeGroupTask();
       

        return tasks;
    }

    @Override
    public CollectorFactory[] getCollectors()
    {
        return new CollectorFactory[0];
    }

    @Override
    public CloupiaReport[] getReports()
    {
        CloupiaReport[] reports = new CloupiaReport[21];
        reports[0] = new PureSummaryReport();
        reports[1] = new VolumeReport();
        reports[2] = new HostReport();
        reports[3] = new SpaceReport();
        reports[4] = new HostGroupReport();
        reports[5] = new ChildHostReport();
        reports[6] = new SnapshotReport();
        reports[7] = new ProtectionGroupReport();
        reports[8] = new ArrayReport();
        reports[9] = new NetworkReport();
        reports[10] = new HostConnectionReport();
        reports[11] = new FcPortsReport();
        reports[12] = new IqnPortsReport();
        reports[13] = new HostVolumeReport();
        reports[14] = new HostGroupVolumeReport();
        reports[15] = new ProtectionGroupVolumeReport();
        reports[16] = new ProtectionGroupHostReport();
        reports[17] = new ProtectionGroupHostGroupReport();
        reports[18] = new PodReport();
        reports[19] = new VolumeGroupReport();
        reports[20] = new AccountSystemTaskReport();
        
       // reports[19] = new AccountSystemTaskReport();
        
        
        
        
        
        return reports;
    }

    @Override
    public void onStart(CustomFeatureRegistry cfr)
    {
        try
        {
            ReportContextRegistry.getInstance().register(PureConstants.PURE_ACCOUNT_TYPE, PureConstants.PURE_ACCOUNT_LABEL);
            ReportContextRegistry.getInstance().register("com.purestorage.flasharray.hostgroup", "HostGroup Report");
            
            //ReportContextRegistry.getInstance().register("FlashArray", "FlashArray");
            cfr.registerLovProviders(FlashArrayAccountsNameProvider.NAME, new FlashArrayAccountsNameProvider());
            cfr.registerLovProviders(TimeUnitProvider.NAME, new TimeUnitProvider());
            cfr.registerLovProviders(TimeClockProvider.NAME, new TimeClockProvider());
            cfr.registerLovProviders(VolumeSizeUnitProvider.NAME, new VolumeSizeUnitProvider());
            cfr.registerTabularField(PortTabularProvider.TABULAR_PROVIDER, PortTabularProvider.class, "2", "2");
            cfr.registerTabularField(PortIQNTabularProvider.TABULAR_PROVIDER, PortIQNTabularProvider.class, "2", "2");
            cfr.registerTabularField(NetworkPortListTabularProvider.TABULAR_PROVIDER, NetworkPortListTabularProvider.class, "3", "3");
            cfr.registerTabularField(VolumeTabularProvider.TABULAR_PROVIDER, VolumeTabularProvider.class, "0", "2");
            cfr.registerTabularField(HostTabularProvider.TABULAR_PROVIDER, HostTabularProvider.class, "0", "2");
            cfr.registerTabularField(HostGroupTabularProvider.TABULAR_PROVIDER, HostGroupTabularProvider.class, "0", "2");
            cfr.registerTabularField(SnapshotTabularProvider.TABULAR_PROVIDER, SnapshotTabularProvider.class, "0", "2");
            cfr.registerTabularField(ProtectionGroupTabularProvider.TABULAR_PROVIDER, ProtectionGroupTabularProvider.class, "0", "2");
            cfr.registerTabularField(SubnetTabularProvider.TABULAR_PROVIDER, SubnetTabularProvider.class, "0", "2");
            cfr.registerTabularField(ConnectionArrayTabularProvider.TABULAR_PROVIDER, ConnectionArrayTabularProvider.class, "0", "2");
            cfr.registerTabularField(NetworkInterfaceListTabularProvider.TABULAR_PROVIDER, NetworkInterfaceListTabularProvider.class, "0", "2");
            cfr.registerTabularField(PodTabularProvider.TABULAR_PROVIDER, PodTabularProvider.class, "0", "2");
            cfr.registerTabularField(VolumeGroupTabularProvider.TABULAR_PROVIDER, VolumeGroupTabularProvider.class, "0", "2");
            
            cfr.registerLovProviders(ArrayTypeProvider.NAME, new ArrayTypeProvider());
            
            
            String fieldName = PortTabularProvider.TABULAR_PROVIDER;//your tabel name
			WorkflowInputTypeRegistry sampleInputType = WorkflowInputTypeRegistry.getInstance();
			sampleInputType.addDeclaration(new WorkflowInputFieldTypeDeclaration(
		                "pureFlashArrayTargetPortMultiWwpn(s)", "Pure Storage FlashArray Target WWPN(s)",
		                FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP,fieldName, true));
			
			 String fieldName1 = PortIQNTabularProvider.TABULAR_PROVIDER;//your tabel name
				WorkflowInputTypeRegistry sampleInputType1 = WorkflowInputTypeRegistry.getInstance();
				sampleInputType1.addDeclaration(new WorkflowInputFieldTypeDeclaration(
			                "pureFlashArrayTargetPortMultiIqn(s)", "Pure Storage FlashArray Target IQN(s)",
			                FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP,fieldName1, true));
			
			
			String tabVol = VolumeTabularProvider.TABULAR_PROVIDER;//your tabel name
			WorkflowInputTypeRegistry volMulInputType = WorkflowInputTypeRegistry.getInstance();
			volMulInputType.addDeclaration(new WorkflowInputFieldTypeDeclaration(
					PureConstants.PURE_VOLUME_LIST_TABLE_NAMES, PureConstants.PURE_VOLUME_LIST_TABLE_LABLES,
		                FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP,tabVol, true));
			
			String tabSnap = SnapshotTabularProvider.TABULAR_PROVIDER;//your tabel name
			WorkflowInputTypeRegistry snapMulInputType = WorkflowInputTypeRegistry.getInstance();
			volMulInputType.addDeclaration(new WorkflowInputFieldTypeDeclaration(
					PureConstants.PURE_SNAPSHOT_LIST_TABLE_NAMES, PureConstants.PURE_SNAPSHOT_LIST_TABLE_LABLES,
		                FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP,tabSnap, true));
			
			String tabHost = HostTabularProvider.TABULAR_PROVIDER;//your tabel name
			WorkflowInputTypeRegistry hostMulInputType = WorkflowInputTypeRegistry.getInstance();
			hostMulInputType.addDeclaration(new WorkflowInputFieldTypeDeclaration(
					PureConstants.PURE_HOST_LIST_TABLE_NAMES, PureConstants.PURE_HOST_LIST_TABLE_LABLES,
		                FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP,tabHost, true));
			
			cfr.registerWorkflowInputFieldType(PureConstants.PURE_VOLUME_LIST_TABLE_NAME, PureConstants.PURE_VOLUME_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, VolumeTabularProvider.TABULAR_PROVIDER);
			
			cfr.registerWorkflowInputFieldType(PureConstants.PURE_SNAPSHOT_LIST_TABLE_NAME, PureConstants.PURE_SNAPSHOT_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, SnapshotTabularProvider.TABULAR_PROVIDER);
			
			
			cfr.registerWorkflowInputFieldType(PureConstants.PURE_HOST_LIST_TABLE_NAME, PureConstants.PURE_HOST_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, HostTabularProvider.TABULAR_PROVIDER);
			cfr.registerWorkflowInputFieldType(PureConstants.PURE_HOSTGROUP_NAME, PureConstants.PURE_HOSTGROUP_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, HostGroupTabularProvider.TABULAR_PROVIDER);
			
			
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_PORT_TABLE_NAME, PureConstants.PURE_PORT_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, PortTabularProvider.TABULAR_PROVIDER);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_PORT_TABLE_IQN_NAME, PureConstants.PURE_PORT_TABLE_IQN_LABLE,
              		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, PortIQNTabularProvider.TABULAR_PROVIDER);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_NETWORK_PORT_LIST_TABLE_NAME, PureConstants.PURE_NETWORK_PORT_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, NetworkPortListTabularProvider.TABULAR_PROVIDER);
           
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME, PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_LABLE,
                    6, FlashArrayAccountsNameProvider.NAME);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_TIME_UNIT_LOV_NAME, PureConstants.PURE_TIME_UNIT_LOV_LABLE,
                    6, TimeUnitProvider.NAME);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_TIME_CLOCK_LOV_NAME, PureConstants.PURE_TIME_CLOCK_LOV_LABLE,
                    6, TimeClockProvider.NAME);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_VOLUME_SIZE_UNIT_LOV_NAME, PureConstants.PURE_VOLUME_SIZE_UNIT_LOV_LABLE,
                    6, VolumeSizeUnitProvider.NAME);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_PROTECTIONGROUP_LIST_TABLE_NAME, PureConstants.PURE_PROTECTIONGROUP_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, ProtectionGroupTabularProvider.TABULAR_PROVIDER);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_SUBNET_LIST_TABLE_NAME, PureConstants.PURE_SUBNET_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, SubnetTabularProvider.TABULAR_PROVIDER);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_CONNECTIONARRAY_LIST_TABLE_NAME, PureConstants.PURE_CONNECTIONARRAY_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, ConnectionArrayTabularProvider.TABULAR_PROVIDER);
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_NETWORK_INTERFACE_LIST_TABLE_NAME, PureConstants.PURE_NETWORK_INTERFACE_LIST_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, NetworkInterfaceListTabularProvider.TABULAR_PROVIDER);
            
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_POD_TABLE_NAME, PureConstants.PURE_POD_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, PodTabularProvider.TABULAR_PROVIDER);
            
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_VOLUMEGROUP_TABLE_NAME, PureConstants.PURE_VOLUMEGROUP_TABLE_LABLE,
            		FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, VolumeGroupTabularProvider.TABULAR_PROVIDER);
            
            cfr.registerWorkflowInputFieldType(PureConstants.PURE_ARRAY_TYPE_LOV_NAME, PureConstants.PURE_ARRAY_TYPE_LOV_LABLE,
                    6, ArrayTypeProvider.NAME);
            
            WorkflowInputTypeRegistry instance = WorkflowInputTypeRegistry.getInstance();

        	
        	instance.setMappable(WorkflowInputFieldTypeDeclaration.GENERIC_TEXT, PureConstants.PURE_CONNECTIONARRAY_LIST_TABLE_NAME);
        	instance.setMappable(PureConstants.PURE_CONNECTIONARRAY_LIST_TABLE_NAME, WorkflowInputFieldTypeDeclaration.GENERIC_TEXT);
            
            createFlashArrayAccountType();
        }
        catch (Exception e)
        {
            logger.error("Could not register FlashArray account.", e);
        }
    }

    private void createFlashArrayAccountType() throws Exception
    {
        logger.info("Creating FlashArray account type.");

        AccountTypeEntry entry = new AccountTypeEntry();
        entry.setCredentialClass(FlashArrayAccount.class);
        entry.setAccountType("FlashArray");
        entry.setAccountLabel("FlashArray");
        entry.setVendor("Pure Storage");
        entry.setCategory(InfraAccountTypes.CAT_STORAGE);
        entry.setContextType(ReportContextRegistry.getInstance().getContextByName(PureConstants.PURE_ACCOUNT_TYPE).getType());
        entry.setAccountClass(AccountTypeEntry.PHYSICAL_ACCOUNT);
        entry.setInventoryTaskPrefix("FlashArray Task");
        entry.setWorkflowTaskCategory("FlashArray Tasks");
        entry.setInventoryFrequencyInMins(15);
        entry.setPodTypes(new String[]{"GenericPod","FlashStack"});
        entry.setIconPath("/app/uploads/openauto/pure4.png");

        entry.setTestConnectionHandler(new FlashArrayTestConnectionHandler());
        entry.setInventoryListener(new FlashArrayInventoryListener());
        entry.setConvergedStackComponentBuilder(new FlashArrayConvergedStackBuilder());
        entry.setCredentialParser(new FlashArrayAccountCredentialParser());
        
        logger.info("******************Registrering Credential Parser**********************");

        entry.createInventoryRoot("flasharray.inventory.root", FlashArrayInventoryItemHandler.class);
       // entry.createInventoryRoot("flasharray.inventory.volume", FlashArrayInventoryItemHandler.class);
      //register account cleanup task
		logger.info("Registering FlashArray account cleanup task");
		registerFlashArrayAccountCleanupTask();
        PhysicalAccountTypeManager.getInstance().addNewAccountType(entry);
    }
    
    private void registerFlashArrayAccountCleanupTask() {
		// TODO Auto-generated method stub
		SystemScheduler scheduler = SystemScheduler.getInstance();
		scheduler.addTask(FlashArrayAccountCleanupTask.displayLabel, "Deletes flasharray account data that have been deleted from the system",
				"FlashArray Tasks", new FlashArrayAccountCleanupTask(), null);
	}
    
    @Override
	public void installMoPointer(MoParser parser) {
    	try {		    		
    		logger.info("#############  Installing OA Storage APIs " );
    		/*
    		 * Rest Adaptor is used to handle the CRUD operations for the Resource. 
    		 * we can extend the adaptor functionality by inheriting the WFTaskRestAdaptor. 
    		 * We can override the methods createResource, updateResource, deleteResource and query according to the need
    		 */
    		
    		 MoPointer p;
    		WFTaskRestAdaptor volumeAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_Volume", "FlashArray.ID.Volume", volumeAdaptor, VolumeInventoryConfig.class);  
           
            p.createOARestOperation("Clone_Volume", PureConstants.TASK_NAME_CLONE_VOLUME_TASK, CloneVolumeTaskConfig.class);  
            p.createOARestOperation("Delete_Volume", PureConstants.TASK_NAME_DESTROY_VOLUMES_SUFFIX_RANGE, DestroyVolumesTaskConfig.class);
            p.createOARestOperation("Create_Volume", PureConstants.TASK_NAME_NEW_VOLUME, NewVolumeTaskConfig.class);
            p.createOARestOperation("Resize_Volume", PureConstants.TASK_NAME_RESIZE_VOLUME, ResizeVolumeTaskConfig.class);
            p.createOARestOperation("Restore_Volume", PureConstants.TASK_NAME_RESTORE_VOLUME_FROM_SNAPSHOT, RestoreVolumeTaskConfig.class);

            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p);
           
            WFTaskRestAdaptor hostAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_Host", "FlashArray.ID.Host", hostAdaptor, HostInventoryConfig.class);  
            
            p.createOARestOperation("Create_Host", PureConstants.TASK_NAME_NEW_HOST, NewHostTaskConfig.class);   
            p.createOARestOperation("Delete_Host", PureConstants.TASK_NAME_DELETE_HOST, DeleteHostTaskConfig.class);

            p.createOARestOperation("Connect_Host_To_Volume", PureConstants.TASK_NAME_CONNECT_HOST_VOLUME, ConnectHostVolumeTaskConfig.class);
            p.createOARestOperation("Connect_WWWN_To_Host", PureConstants.TASK_NAME_CONNECT_WWN_To_HOST, ConnectWWWNToHostTaskConfig.class);
            p.createOARestOperation("Disconnect_Volume_With_Host", PureConstants.TASK_NAME_DISCONNECT_VOLUMES_WITH_HOST, DisconnectVolumeHostTaskConfig.class);

            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p);
            
            WFTaskRestAdaptor hostGroupAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_HostGroup", "FlashArray.ID.HostGroup", hostGroupAdaptor, HostGroupInventoryConfig.class);  
            /*
             * createOARestOperation is mandatory method to register REST APIs operations via Open Automation connector.
             * @param0 defines Operation name. mandatory field.
             * @Param1 is resource Handler name. mandatory field.Using this handler name we are handling for the REST API Operation.
             * @param2 is resource config class. mandatory field.For a particular handler operation config is required.
             */
            
            p.createOARestOperation("Create_HostGroup", PureConstants.TASK_NAME_NEW_HOSTGROUP, NewHostGroupTaskConfig.class);
            p.createOARestOperation("Delete_HostGroup", PureConstants.TASK_NAME_DELETE_HG_SUFFIX_RANGE, DeleteHGSuffixRangeTaskConfig.class);
            p.createOARestOperation("Connect_Host_To_HostGroup", PureConstants.TASK_NAME_CONNECT_HOST_HOSTGROUP, ConnectHostToHGTaskConfig.class);
            p.createOARestOperation("Connect_Volume_to_HostGroup", PureConstants.TASK_NAME_CONNECT_VOLUME_HOSTGROUP, ConnectVolumeToHGTaskConfig.class);
            p.createOARestOperation("Disconnect_Volume_With_HostGroup", PureConstants.TASK_NAME_DISCONNECT_VOLUMES_WITH_HOSTGROUP, DisconnectVolumeHGTaskConfig.class);
            p.createOARestOperation("Disconnect_Hosts_With_HostGroup", PureConstants.TASK_NAME_DISCONNECT_HOSTS_WITH_HOSTGROUP, DisconnectHostHGTaskConfig.class);
           
            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p);
           

            WFTaskRestAdaptor ProtectionGroupAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_ProtectionGroup", "FlashArray.ID.ProtectionGroup", ProtectionGroupAdaptor, ProtectionGroupInventoryConfig.class);  
            /*
             * createOARestOperation is mandatory method to register REST APIs operations via Open Automation connector.
             * @param0 defines Operation name. mandatory field.
             * @Param1 is resource Handler name. mandatory field.Using this handler name we are handling for the REST API Operation.
             * @param2 is resource config class. mandatory field.For a particular handler operation config is required.
             */
            
            p.createOARestOperation("Add_Volume_Protectiongroup", PureConstants.TASK_NAME_ADD_VOLUME_PROTECTIONGROUP_TASK, AddVolumeProtectionGroupTaskConfig.class);
            p.createOARestOperation("Add_Host_Protectiongroup", PureConstants.TASK_NAME_ADD_HOST_PROTECTIONGROUP_TASK, AddHostProtectionGroupTaskConfig.class);
            p.createOARestOperation("Add_Target_ProtectionGroup", PureConstants.TASK_NAME_ADD_CONNECTIONARRAY_PROTECTIONGROUP_TASK, AddTargetProtectionGroupTaskConfig.class);
            p.createOARestOperation("Create_ProtectionGroup", PureConstants.TASK_NAME_CREATE_PROTECTIONGROUP_TASK, CreateProtectionGroupTaskConfig.class);
            p.createOARestOperation("Create_ProtectionGroup_with_HostGroup", PureConstants.TASK_NAME_CREATE_PROTECTIONGROUPWITHHOSTGROUP_TASK, CreateProtectionGroupWithHostGroupTaskConfig.class);
            p.createOARestOperation("Delete_ProtectionGroup", PureConstants.TASK_NAME_DELETE_PROTECTIONGROUP_TASK, DeleteProtectionGroupTaskConfig.class);
            p.createOARestOperation("Remove_Target_ProtectionGroup", PureConstants.TASK_NAME_REMOVE_CONNECTIONARRAY_PROTECTIONGROUP_TASK, RemoveTargetProtectionGroupTaskConfig.class);
            p.createOARestOperation("Remove_Volume_From_ProtectionGroup", PureConstants.TASK_NAME_REMOVE_VOLUME_PROTECTIONGROUP_TASK, RemoveVolumeProtectionGroupTaskConfig.class);
            
            
            
            /*
             * Category is for the rest API browser folder structor.
             */
            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p);
           
           
            WFTaskRestAdaptor SnapshotAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_Snapshot", "FlashArray.ID.Snapshot", SnapshotAdaptor, SnapshotInventoryConfig.class);  
            /*
             * createOARestOperation is mandatory method to register REST APIs operations via Open Automation connector.
             * @param0 defines Operation name. mandatory field.
             * @Param1 is resource Handler name. mandatory field.Using this handler name we are handling for the REST API Operation.
             * @param2 is resource config class. mandatory field.For a particular handler operation config is required.
             */
            
            p.createOARestOperation("Clone_Snapshot", PureConstants.TASK_NAME_CLONE_SNAPSHOT_TASK, CloneSnapshotTaskConfig.class);
            p.createOARestOperation("Delete_Schedule_Snapshot", PureConstants.TASK_NAME_DELETE_SCHEDULE_SNAPSHOT, DeleteScheduleSnapshotTaskConfig.class);
            p.createOARestOperation("Delete_Snapshot", PureConstants.TASK_NAME_DESTROY_SNAPSHOT, DestroySnapshotTaskConfig.class);
            p.createOARestOperation("Schedule_Volume_Snapshot", PureConstants.TASK_NAME_SCHEDULE_VOLUME_SNAPSHOT, ScheduleVolumeSnapshotTaskConfig.class);
            
            
            
            /*
             * Category is for the rest API browser folder structor.
             */
            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p);  
            
            WFTaskRestAdaptor VlanAdaptor = new WFTaskRestAdaptor();
    		/*
    		 * MoPointer is the placeholder to register the REST APIs.
    		 * @param0 is to define the resource name. mandatory field.
    		 * @param1 is to define for  the ResourceURL.mandatory field.
    		 * @param2 is restAdaptor. mandatory field.
    		 * @param3 is the resource config class. mandatory field.
      		 * If we don't want to READ Operation for the api have to use below constructor.
    		 * MoPointer(String name, String path, MoResourceListener moListener, Class moModel, boolean isMoPersistent ,boolean isReadAPISupported)
    		 * mopointer IS successfully registered API then only we can see the API in REST API Browser.
    		 */
    		 
            p = new MoPointer("FlashArray_Vlan", "FlashArray.ID.Vlan", VlanAdaptor, null);  
            /*
             * createOARestOperation is mandatory method to register REST APIs operations via Open Automation connector.
             * @param0 defines Operation name. mandatory field.
             * @Param1 is resource Handler name. mandatory field.Using this handler name we are handling for the REST API Operation.
             * @param2 is resource config class. mandatory field.For a particular handler operation config is required.
             */
            
            p.createOARestOperation("Create_Vlan", PureConstants.TASK_NAME_CREATE_VLAN_TASK, CreateVlanTaskConfig.class); 
            p.createOARestOperation("Delete_Vlan", PureConstants.TASK_NAME_DELETE_VLAN_TASK, DeleteVlanTaskConfig.class);
            
            /*
             * Category is for the rest API browser folder structor.
             */
            p.setCategory(PureConstants.REST_API_FOLDER_NAME);
            /*
             * Registered REST APIs intimated to the framework through the MoParser.It is mandatory to load any REST APis in in the framework.
             */
            parser.addMoPointer(p); 
            
            
            
    	} catch (Exception e) {
    		logger.error("Error installing OA Storage APIs " + e);
    	}
    
    
    
    
    
    
    
    }
    
}
