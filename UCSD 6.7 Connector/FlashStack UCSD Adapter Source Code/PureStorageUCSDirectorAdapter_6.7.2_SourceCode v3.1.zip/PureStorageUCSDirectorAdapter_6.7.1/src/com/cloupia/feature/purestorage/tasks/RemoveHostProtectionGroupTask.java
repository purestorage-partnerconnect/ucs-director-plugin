
package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class RemoveHostProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(RemoveHostProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	RemoveHostProtectionGroupTaskConfig config = (RemoveHostProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

        final String hostName = config.getHostName().split("@")[1];
        String protectionGroupName = config.getProtectionGroup().split("@")[1];
        
            

            try
            {
                CLIENT.protectionGroups().removeHosts(protectionGroupName,Arrays.asList(hostName));
            }
            catch(Exception e) {
                actionlogger.addError("There is no exsiting Host " + hostName + "in Protection GRoup.");
                throw e;
            }

           
            
             actionlogger.addInfo("Removing host " + hostName + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           /* context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "Scheduled Snapshot",
                    "Snapshots have been scheduled" + config.getAccountName(),
                    new DeleteScheduleSnapshotTask().getTaskName(), new DeleteScheduleSnapshotTaskConfig(config));
         */   String volIdentity =accountName+"@"+hostName;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_HOST_IDENTITY, volIdentity);
        	actionlogger.addInfo("Host Identity as Output is saved");
        	
        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
        	   
        	
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgConfig = store2.query(query3);
            actionlogger.addInfo("Host Name :"+ pgConfig.get(0).getId());
            //pgconfig.get(0).getHosts();
            String hostsList1= "";
            PureProtectionGroup protectiongroup=CLIENT.protectionGroups().get(protectionGroupName);
    		logger.info(" Host :"+ hostsList1);
    		String hostsList2="";
    		if(protectiongroup.getHosts().isEmpty())
    		{
    			pgConfig.get(0).setHosts("");
    		}
    	else
    		{
    		
    	
    		List<String> hostList = protectiongroup.getHosts();
    		
    		logger.info(" Host :"+ hostsList2);
    		for(String hos1 : hostList)
    			{
    				if(hostsList2 == "")
    					{
    						hostsList2=hos1;
    					}else
    						{
    						hostsList2=hostsList2+","+hos1;
    						}
          }
          	pgConfig.get(0).setHosts(hostsList2);
    		}		  
          		store2.modifySingleObject("id == '" + accountName+"@"+protectionGroupName +"' && hosts == '" + hostsList2 + "'",  pgConfig.get(0));
          			String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
    	            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
    	            actionlogger.addInfo("Host Name :"+ pgconfig1.get(0).getHosts());
    		
    	           
        }


    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_HOST_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"host Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new RemoveHostProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_REMOVE_HOST_PROTECTIONGROUP_TASK;
	}

}