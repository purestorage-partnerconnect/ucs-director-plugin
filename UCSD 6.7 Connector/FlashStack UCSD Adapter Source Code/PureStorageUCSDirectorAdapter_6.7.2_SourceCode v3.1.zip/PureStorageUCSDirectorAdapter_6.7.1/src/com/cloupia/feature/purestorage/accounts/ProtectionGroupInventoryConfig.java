package com.cloupia.feature.purestorage.accounts;

	
	import java.util.List;

	import com.cisco.cuic.api.client.JSON;
	import com.cloupia.fw.objstore.ObjStore;
	import com.cloupia.fw.objstore.ObjStoreHelper;
	import com.cloupia.lib.cIaaS.network.model.DeviceCredential;
	import com.cloupia.lib.connector.account.AbstractInfraAccount;
	import com.cloupia.lib.connector.account.AccountUtil;
	import com.cloupia.lib.connector.account.PhysicalInfraAccount;
	import com.cloupia.model.cIM.FormFieldDefinition;
	import com.cloupia.model.cIM.InfraAccount;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.collector.view2.ConnectorCredential;
	import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;
import com.purestorage.rest.protectiongroup.PureArrayTarget;

import javax.jdo.annotations.Column;
import javax.jdo.annotations.PersistenceCapable;
	import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

	@XmlRootElement(name = "FlashArray_ProtectionGroup")
	@PersistenceCapable(detachable = "true", table = "ProtectionGroup_Inventory_Configg")
 public class ProtectionGroupInventoryConfig implements TaskConfigIf{
	    static Logger logger = Logger.getLogger(ProtectionGroupInventoryConfig.class);

	    // ManagementAddress
	    @Persistent
	    private String id;
	    
	    public String getId()
	    {
	        return id;
	    }

	    public void setId(String id)
	    {
	        this.id = id;
	    }

	   
	   
	    @MoReference(path = "FlashArray.ID")
		@Persistent
	     private String accountName;

	    public void setAccountName(String accountName)
	    {
	        this.accountName = accountName;
	    }

	    
	    public String getAccountName()
	    {
	        return this.accountName;
	    }
	    
	    @MoReference(path = "FlashArray.ID.ProtectionGroup.ID", key = true)
	    @Persistent
	    @Column(length = 1024000000, jdbcType = "CLOB")
	    private String protectionGroupName;

	    
	  
	    
	   



		public String getProtectionGroupName() {
			return protectionGroupName;
		}

		public void setProtectionGroupName(String protectionGroupName) {
			this.protectionGroupName = protectionGroupName;
		}



		@Persistent
	    @Column(length = 1024000000, jdbcType = "CLOB")
	    private String hostgroups ;

	    public String getHostgroups()
	    {
	        return hostgroups;
	    }
	    public void setHostgroups(String list)
	    {
	        this.hostgroups = list;
	    }
	    
	    @Persistent
	    @Column(length = 1024000000, jdbcType = "CLOB")
	    private String hosts ;

	    public String getHosts()
	    {
	        return hosts;
	    }
	    public void setHosts(String list)
	    {
	        this.hosts = list;
	    }
	    
	    @Persistent
	    private String source;

	    
	    public String getSource()
	    {
	        return source;
	    }

	    
	    public void setSource(String source)
	    {
	        this.source = source;
	    }
	    

	    @Persistent
	    @Column(length = 1024000000, jdbcType = "CLOB")
	    private String targets;

	    
	    public String getTargets()
	    {
	        return targets;
	    }

	    
	    public void setTargets(String list)
	    {
	        this.targets = list;
	    }

	    @Persistent
	    @Column(length = 1024000000, jdbcType = "CLOB")
	    private String volumes;

	    
	    public String getVolumes()
	    {
	        return volumes;
	    }

	    
	    public void setVolumes(String list)
	    {
	        this.volumes = list;
	    }

		@Override
		public long getActionId() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public String getDisplayLabel() {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public void setActionId(long arg0) {
			// TODO Auto-generated method stub
			
		}

		@Override
		public long getConfigEntryId() {
			// TODO Auto-generated method stub
			return 0;
		}

		@Override
		public void setConfigEntryId(long arg0) {
			// TODO Auto-generated method stub
			
		}
	    
	   
	  }
