package com.cloupia.feature.purestorage.actions.forms;

import javax.jdo.annotations.Persistent;

import com.cloupia.feature.purestorage.lovs.VolumeSizeUnitProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class CloneSnapshotForm {
	
	  
    @FormField(label = "New Volume Name", help = "Letters, numbers, -, and _", mandatory = true )
    
    @Persistent
    private String snapshotPreName;
   
    
	
	
	public String getSnapshotPreName() {
		return snapshotPreName;
	}

	public void setSnapshotPreName(String snapshotPreName) {
		this.snapshotPreName = snapshotPreName;
	}


	

}
