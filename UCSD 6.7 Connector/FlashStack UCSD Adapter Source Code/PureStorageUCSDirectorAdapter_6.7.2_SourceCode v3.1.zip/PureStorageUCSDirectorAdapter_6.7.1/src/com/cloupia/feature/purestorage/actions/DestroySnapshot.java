package com.cloupia.feature.purestorage.actions;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.SnapshotInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.actions.forms.DestroyVolumeForm;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.model.cIM.ConfigTableAction;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.service.cIM.inframgr.forms.wizard.Page;
import com.cloupia.service.cIM.inframgr.forms.wizard.PageIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaPageAction;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;


public class DestroySnapshot extends CloupiaPageAction {
	private static Logger logger = Logger.getLogger(DestroySnapshot.class);
	
	private static final String formId = "psucs.destroy.snapshot.form";
	private static final String ACTION_ID = "psucs.destroy.snapshot.action";
	private static final String label = "Delete";

	@Override
	public void definePage(Page page, ReportContext context) {
		// TODO Auto-generated method stub
		
		
		page.addLabel("Confirm to delete the Snapshot '"+ context.getId());
	}

	@Override
	public void loadDataToPage(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub

	}

	@Override
	public int validatePageData(Page page, ReportContext context, WizardSession session) throws Exception {
		// TODO Auto-generated method stub
		 String accountName="",snapshotName="";
		 
			
	        if(context.getId().contains("@"))   //Checking the Context 
	        {
	        	 String[] parts = context.getId().split("@",2);
	             accountName = parts[0];
	             snapshotName = parts[1];
	           	
	        }
	        else
	        {
	        	logger.error("Error in Report Generation ..Wrong Conext" + context);
	            
	        }
	        
	      
        
		if (page.isPageSubmitted())
        {
			try{
				FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
				PureRestClient CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

				      
				 
            		 CLIENT.volumes().destroy(snapshotName); 
                
                   
                   logger.info("Destroying Snapshot : " + snapshotName);
                    
                    ObjStore<SnapshotInventoryConfig> store2 = ObjStoreHelper.getStore(SnapshotInventoryConfig.class);
               	   
                    String query3 = "id == '" + accountName+"@"+snapshotName + "'";
                    List<SnapshotInventoryConfig> hconfig = store2.query(query3);
                   logger.info("Snapshot Id :"+ hconfig.get(0).getId());
                
                    long s = store2.delete(query3);
                   logger.info("Deleted in Inventory :" + s);
                
                page.setPageMessage("Successfully destroyed snapshot " + snapshotName+
		                   " on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
				
				
	        	return PageIf.STATUS_OK;
	        }catch(Exception ex){
	        	page.setPageMessage("Error: "+ex.getMessage());
	        	return PageIf.STATUS_ERROR;
	        }
        }
		return PageIf.STATUS_OK;
	}
	
	

	@Override
	public String getActionId() {
		// TODO Auto-generated method stub
		return ACTION_ID;
	}

	@Override
	public int getActionType() {
		// TODO Auto-generated method stub
		return ConfigTableAction.ACTION_TYPE_POPUP_FORM;
	}

	@Override
	public String getFormId() {
		// TODO Auto-generated method stub
		return formId;
	}

	@Override
	public String getLabel() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return label;
	}

	@Override
	public boolean isDoubleClickAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isDrilldownAction() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean isSelectionRequired() {
		// TODO Auto-generated method stub
		return true;
	}

	
}
