package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;

import com.purestorage.rest.volumegroup.PureVolumeGroup;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Arrays;


public class NewVolumeGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(NewVolumeGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	NewVolumeGroupTaskConfig config = (NewVolumeGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking NewVolumeGroupTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount,"1.14");
        
        PureVolumeGroup vg;
        String vgName=config.getVolumeGroupName();
        try
        {
        	 vg=CLIENT.volumeGroups().create(vgName);
        	
        	
       
        }catch(PureException e)
        {
        	actionlogger.addError(e.getMessage());
        	throw new Exception(e.getMessage());
        }
        
        if(vg.getName().equals(vgName))
    	{
    		 ObjStore<VolumeGroupInventoryConfig> store = ObjStoreHelper.getStore(VolumeGroupInventoryConfig.class);
    		 
    		 VolumeGroupInventoryConfig vgConfig=new VolumeGroupInventoryConfig();
    		 
    		 vgConfig.setAccountName(accountName);
    		 vgConfig.setId(accountName+"@"+vgName);
    		 vgConfig.setVolumeGroupName(vgName);
    		 String arrays="";
         
         	
         	store.insert(vgConfig);
    	      
    	}
            actionlogger.addInfo("Successfully created volume group " + vgName +
                    " on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
           
            
            context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_IDENTITY, accountName+"@"+vgName);
            context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_NAME, accountName+"@"+vgName);
        	
        	actionlogger.addInfo("VolumeGroup Identity as Output is saved");
        	
        	//UcsdCmdbUtils cmdb=new UcsdCmdbUtils();
            String description="FlashArray VolumeGroup is created. Details are : Account Name = "+config.getAccountName()+" , VolumeGroup Name = "+ vgName;
            
            UcsdCmdbUtils.updateRecord("FlashArray VolumeGroup", description, 1, context.getUserId(), vgName,description);
            
            //context.getChangeTracker().resourceAdded("FlashArray HostGroup", hostGroupIdentity, hostGroupPreName, description);
            context.getChangeTracker().undoableResourceAdded("FlashArray VolumeGroup : Created", accountName+"@"+vgName, vgName,description,
                    new DeleteVolumeGroupTask().getTaskName(), new DeleteVolumeGroupTaskConfig(config));

            
       
        
    }

  

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[2];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"VolumeGroup Identity(s)");
   		ops[1] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_NAME,
   				PureConstants.PURE_VOLUMEGROUP_TABLE_NAME,
   				"FlashArray VolumeGroup Name");
   		
   		
   		return ops;
    }

	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new NewVolumeGroupTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_VOLUMEGROUP;
	}

}
