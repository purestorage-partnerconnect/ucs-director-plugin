package com.cloupia.feature.purestorage;

import java.util.List;

import com.cloupia.feature.purestorage.accounts.ConnectionArrayInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.purestorage.rest.AbstractPureRestClient;
import com.purestorage.rest.PureApiVersion;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.PureRestClientConfig;
import com.purestorage.rest.array.PureArrayConnection;

public class test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//System.out.println("Hellooo6y7u5ooooooooooooooo");
System.out.println("Helloooooooooooooooooo3434");
String apiEndPoint = "https://10.1.150.169/api";
PureApiVersion restAPIversion = PureApiVersion.fromString("1.7");
System.out.println(":Connecting to Pure FlashArray at [" + apiEndPoint + "] with username [" + "]");
PureRestClientConfig CONFIG = PureRestClientConfig.newBuilder("pureuser", "pureuser", apiEndPoint, restAPIversion)//10.203.128.141
        .setClientInfo(PureConstants.PURE_ADAPTER_NAME, PureConstants.PURE_ADAPTER_VERSION)
        .setIgnoreCertificateError(true)
       .build();

PureRestClient CLIENT = AbstractPureRestClient.create(CONFIG);
//System.out.println(CLIENT.array().getAttributes());
List<PureArrayConnection> connectionarrays =  CLIENT.array().getConnections();

for (PureArrayConnection Connection: connectionarrays)
{
	System.out.println(" Array Name : "+ Connection.getArrayName());
	//ConnectionArrayInventoryConfig ArrayConfig = new ConnectionArrayInventoryConfig();
	System.out.println( Connection.getArrayName());
	System.out.println(Connection.getManagementAddress());
	System.out.println(Connection.getReplicationAddress());
}

	}

}
