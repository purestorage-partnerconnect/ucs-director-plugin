package com.cloupia.feature.purestorage.lovs;

import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.ConnectionArrayInventoryConfig;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeGroupInventoryConfig;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;

public class VolumeGroupTabularProvider implements TabularReportGeneratorIf {

	public static final String TABULAR_PROVIDER = "pure_volumegroup_tabular_provider";
	 static Logger logger = Logger.getLogger(VolumeGroupTabularProvider.class);
	
	

	@Override
	public TabularReport getTabularReportReport(ReportRegistryEntry reportEntry, ReportContext context) throws Exception {
		
		
        TabularReport report = new TabularReport();

		report.setGeneratedTime(System.currentTimeMillis());
		report.setReportName(reportEntry.getReportLabel());
		report.setContext(context);

		TabularReportInternalModel model = new TabularReportInternalModel();

			model.addTextColumn("Id", "Id",true);
		 	model.addTextColumn("Account Name", "Name of Account ");
	        model.addTextColumn("Volume Groups", "Name of Pod");
	        model.addNumberColumn("No. Of Volumes", "No. Of Volumes");
	        model.addLongNumberColumn("Snapshots (GB)", "Snapshots");
	        model.addLongNumberColumn("Volumes (GB)", "Volumes");
	        model.addDoubleColumn("Total (GB)", "Total");
        model.completedHeader();
		List<PhysicalInfraAccount> accounts = AccountUtil.getAccountsByType("FlashArray");
        
		String accountName=null;
        int i = 0;
        
        
        if(context.getId().contains("@"))   //Checking the Context 
        {
        	 String[] parts = context.getId().split("@",2);
             accountName = parts[0];
             
             logger.info("*************Found account:" + accountName +"		Context :"+context.getId());
	            
        
             List<VolumeGroupInventoryConfig> vgs= PureUtils.getAllPureVolumeGroup();
             for (VolumeGroupInventoryConfig vg: vgs)
             {
            	 if (accountName.equalsIgnoreCase(vg.getAccountName()))
                 {
            		 			model.addTextValue(vg.getId());
                          	model.addTextValue(accountName);
                              model.addTextValue(vg.getVolumeGroupName()); 
                              model.addNumberValue(vg.getNoVolume()); 
                              model.addLongNumberValue(vg.getSnapshots()); 
                              model.addLongNumberValue(vg.getVolumes()); 
                              model.addDoubleValue(vg.getTotal()); 
                       
                         model.completedRow();
                  }
             }
        }
        else
        {
        for (PhysicalInfraAccount account:accounts)
        {
      	  
             accountName = account.getAccountName();
            logger.info("Found account:" + accountName);
            if (accountName != null && accountName.length() > 0)
            {
            	/*FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
                PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
                List<PureHost> hosts =  CLIENT.hosts().list();*/
            	//model.addTextValue(host.getId());
            	List<VolumeGroupInventoryConfig> vgs= PureUtils.getAllPureVolumeGroup();
                for (VolumeGroupInventoryConfig vg: vgs)
                {
               	 if (accountName.equalsIgnoreCase(vg.getAccountName()))
                    {
               		 			model.addTextValue(vg.getId());
                             	model.addTextValue(accountName);
                                 model.addTextValue(vg.getVolumeGroupName()); 
                                 model.addNumberValue(vg.getNoVolume()); 
                                 model.addLongNumberValue(vg.getSnapshots()); 
                                 model.addLongNumberValue(vg.getVolumes()); 
                                 model.addDoubleValue(vg.getTotal()); 
                          
                            model.completedRow();
                     }
                }
            }
        }
        }

		model.updateReport(report);

		return report;
	}

}

