package com.cloupia.feature.purestorage.lovs;

import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;

public class PodTabularProvider implements TabularReportGeneratorIf {

	public static final String TABULAR_PROVIDER = "pure_pod_tabular_provider";
	 static Logger logger = Logger.getLogger(PodTabularProvider.class);
	
	

	@Override
	public TabularReport getTabularReportReport(ReportRegistryEntry reportEntry, ReportContext context) throws Exception {
		
		
        TabularReport report = new TabularReport();

		report.setGeneratedTime(System.currentTimeMillis());
		report.setReportName(reportEntry.getReportLabel());
		report.setContext(context);

		TabularReportInternalModel model = new TabularReportInternalModel();

       
        model.addTextColumn("Account Name", "Name of Account ");
        model.addTextColumn("Pods", "Name of Pod");
        model.addTextColumn("Array", "Array");
        model.addLongNumberColumn("Snapshots", "Snapshots", false);
        model.addLongNumberColumn("Volumes", "Volumes");
        model.addDoubleColumn("Total", "Total");
        model.addDoubleColumn("Reduction", "Reduction");
        model.completedHeader();
		List<PhysicalInfraAccount> accounts = AccountUtil.getAccountsByType("FlashArray");
        
        int i = 0;
        for (PhysicalInfraAccount account:accounts)
        {
      	  
            String accountName = account.getAccountName();
            logger.info("Found account:" + accountName);
            if (accountName != null && accountName.length() > 0)
            {
            	/*FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
                PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
                List<PureHost> hosts =  CLIENT.hosts().list();*/
            	//model.addTextValue(host.getId());
                		 List<PodInventoryConfig> pods= PureUtils.getAllPurePod();
                         for (PodInventoryConfig pod: pods)
                         {
                        	 if (accountName.equalsIgnoreCase(pod.getAccountName()))
                             {
                          
                        	
                        	model.addTextValue(accountName);
                            model.addTextValue(pod.getPodName()); // Name
                            model.addTextValue(pod.getArray()); //PodGroup
                            model.addLongNumberValue(pod.getSnapshots()); // Number of volumes
                            model.addLongNumberValue(pod.getVolumes()); // Number of volumes
                            model.addDoubleValue(pod.getTotal()); // Number of volumes
                            model.addDoubleValue(pod.getReduction()); // Number of volumes
                          
                            model.completedRow();
                     }
                }
            }
        }

		model.updateReport(report);

		return report;
	}

}

