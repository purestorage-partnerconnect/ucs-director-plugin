package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeGroupInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;
import com.purestorage.rest.hostgroup.PureHostGroupConnection;

import com.purestorage.rest.volume.PureVolumeSpaceMetrics;
import com.purestorage.rest.volumegroup.PureVolumeGroup;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;


public class MoveVolumeVGTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(MoveVolumeVGTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	MoveVolumeVGTaskConfig config = (MoveVolumeVGTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking VolumeGroupTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);


        String vgName = config.getVolumeGroupName();
       String volumeName = config.getVolumeName();
                 try
                 {
                	 CLIENT.volumes().addVolume(volumeName, vgName);
                    actionlogger.addInfo("Adding Volume "+volumeName+" volume group " + vgName);
                    ObjStore<VolumeGroupInventoryConfig> store2 = ObjStoreHelper.getStore(VolumeGroupInventoryConfig.class);
             	   
                    String query3 = "id == '" + accountName+"@"+vgName + "'";
                    List<VolumeGroupInventoryConfig> vgConfig = store2.query(query3);
                    actionlogger.addInfo("VolumeGroup Id :"+ vgConfig.get(0).getId());
                    
                   
                	
               	 long snapshots=0;
               	   
               	 long volumes=0;
               	   
               	 double total=0.0;
               	 double reduction=0.0;
               	 
               	PureVolumeGroup vg =  CLIENT.volumeGroups().get(vgName);
               	 
               	
               	 vgConfig.get(0).setNoVolume(vg.getVolumes().size());
               
               		PureVolumeSpaceMetrics space= CLIENT.volumeGroups().getSpaceMetrics(vgName);
               		
               		volumes=space.getVolumes();
               		snapshots=space.getSnapshots();
               		total=space.getTotal();
               		reduction =space.getDataReduction();
               	
               	
               	
               	vgConfig.get(0).setVolumes(volumes/(1024*1024*1024));
               	vgConfig.get(0).setSnapshots(snapshots/(1024*1024*1024));
               	vgConfig.get(0).setTotal(total/(1024*1024*1024));
               	vgConfig.get(0).setReduction(reduction);
                	 
                	volumes=volumes/(1024*1024*1024);
                	snapshots=snapshots/(1024*1024*1024);
                	total=total/(1024*1024*1024);
                	int v=vg.getVolumes().size();
                	
                	 if (v == 0)
                     {
                     	store2.modifySingleObject("noVolume == '" + v +"' && volumes == " + volumes + " && snapshots == " + snapshots +" && total == " + total +" && reduction == " + reduction,  vgConfig.get(0));
                        	
                     }
                     else
                     {
                    	 store2.modifySingleObject("noVolume == " + v +" && volumes == " + volumes + " && snapshots == " + snapshots +" && total == " + total +" && reduction == " + reduction,  vgConfig.get(0));
                           
                     }
                	
                      
                    
                    actionlogger.addInfo("Moved Volumed in Inventory " );
                }
            
            catch (PureException e)
            {
                actionlogger.addError("Error happens while moving volume in vg : " + vgName + "Exception: " + e.getMessage());
                throw e;
            }
          
        
        
    	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_IDENTITY, accountName+"@"+vgName);
    	actionlogger.addInfo("VolumeGroup Identity as Output is saved");
    	
    	String description="FlashArray VolumeGroup is Modified. Details are : Account Name = "+config.getAccountName()+" , VolumeGroup Name = "+ vgName;
        
       // UcsdCmdbUtils.updateRecord("FlashArray VolumeGroup", description, 2, context.getUserId(), vgName,description);
        
       // context.getChangeTracker().resourceAdded("FlashArray VolumeGroup : MoveVolumed",accountName+"@"+vgName, vgName, description);
    	context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "MovedVolumesToVolumeGroup",
                "Volumes has been moved to vg " + config.getAccountName(),
                new MoveOutVolumeVGTask().getTaskName(), new MoveOutVolumeVGTaskConfig(config));
    
    }

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_VOLUMEGROUP_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"VolumeGroup Identity(s)");
   		return ops;
    }


   
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new MoveVolumeVGTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_MOVE_VOLUME_VOLUMEGROUP;
	}

}
