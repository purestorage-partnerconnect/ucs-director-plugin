package com.cloupia.feature.purestorage.tasks;


import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.PodInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.exceptions.PureException;
import com.purestorage.rest.hostgroup.PureHostGroup;
import com.purestorage.rest.hostgroup.PureHostGroupConnection;
import com.purestorage.rest.pod.PurePod;
import com.purestorage.rest.pod.PurePodArray;
import com.purestorage.rest.pod.PurePodSpace;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;


public class AddArrayPodTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(AddArrayPodTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	AddArrayPodTaskConfig config = (AddArrayPodTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking PodTask accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);


        String podName = config.getPodName();
        String arrayName = config.getArrayName();
                 try
                 {
                	 CLIENT.pods().addArray(podName, arrayName);
                    actionlogger.addInfo("Adding Array "+arrayName+" to pod " + podName);
                    ObjStore<PodInventoryConfig> store2 = ObjStoreHelper.getStore(PodInventoryConfig.class);
             	   
                    String query3 = "id == '" + accountName+"@"+podName + "'";
                    List<PodInventoryConfig> podConfig = store2.query(query3);
                    actionlogger.addInfo("Pod Id :"+ podConfig.get(0).getId());
                    
                    PurePod space=CLIENT.pods().listNamedPod(podName).get(0);
                    
                    
                	 
                    String arrays="";
                	for(PurePodArray arr :space.getArrays())
                		arrays= arrays+","+arr.getName();
                	
                	podConfig.get(0).setArray(arrays.substring(1, arrays.length()));
                	
                
                	
                     store2.modifySingleObject("array == '" + arrays+"'" ,  podConfig.get(0));
                     
                    
                    actionlogger.addInfo("Added Array in Inventory " );
                }
            
            catch (PureException e)
            {
                actionlogger.addError("Error happens while adding array in pod : " + podName + "Exception: " + e.getMessage());
                throw e;
            }
          
        
        
    	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY, accountName+"@"+podName);
    	actionlogger.addInfo("Pod Identity as Output is saved");
    	
    	String description="FlashArray Pod is Modified. Details are : Account Name = "+config.getAccountName()+" , Pod Name = "+ podName;
        
       // UcsdCmdbUtils.updateRecord("FlashArray Pod", description, 2, context.getUserId(), podName,description);
        
       // context.getChangeTracker().resourceAdded("FlashArray Pod : AddArrayd",accountName+"@"+podName, podName, description);
    	/*context.getChangeTracker().undoableResourceModified("AssetType", "idstring", "MovedVolumesToPod",
                "Volumes has been moved to pod " + config.getAccountName(),
                new MoveOutVolumePodTask().getTaskName(), new MoveOutVolumePodTaskConfig(config));*/
    
    }

    @Override
    public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_POD_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Pod Identity(s)");
   		return ops;
    }


   
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new AddArrayPodTaskConfig();
	}

	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_ADD_ARRAY_POD;
	}

}
