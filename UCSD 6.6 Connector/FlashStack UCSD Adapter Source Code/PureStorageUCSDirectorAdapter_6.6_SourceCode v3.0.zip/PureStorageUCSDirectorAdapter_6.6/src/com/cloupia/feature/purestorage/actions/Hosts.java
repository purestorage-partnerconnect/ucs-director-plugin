package com.cloupia.feature.purestorage.actions;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.UcsdCmdbUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.model.cIM.ConfigTableAction;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.service.cIM.inframgr.forms.wizard.DataManagerIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.Page;
import com.cloupia.service.cIM.inframgr.forms.wizard.PageIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaPageAction;
import com.cloupia.service.cIM.inframgr.reports.simplified.CloupiaReportAction;
import com.cloupia.service.cIM.inframgr.reports.simplified.actions.DrillDownAction;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.host.PureHostConnection;

public class Hosts implements CloupiaReportAction {
	private static Logger logger = Logger.getLogger(Hosts.class);
	
	//private static final String formId = "psucs.host.form";
	private static final String ACTION_ID = "psucs.host.action";
	private static final String label = "Hosts";
	
	
	public Hosts() {
		super();
		// TODO Auto-generated constructor stub
	}


	@Override
	public String getActionId() {
		// TODO Auto-generated method stub
		return ACTION_ID;
	}


	@Override
	public int getActionType() {
		// TODO Auto-generated method stub
		return 3;
	}


	

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getFormId() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String getLabel() {
		// TODO Auto-generated method stub
		return label;
	}


	@Override
	public String getOperationalLevel() {
		// TODO Auto-generated method stub
		return "write_users_and_groups";
	}


	@Override
	public String getTitle() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean isDoubleClickAction() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isDrilldownAction() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public boolean isMultiPageAction() {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean isSelectionRequired() {
		// TODO Auto-generated method stub
		return true;
	}


	@Override
	public DataManagerIf<?> getDataManagerImpl() {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
