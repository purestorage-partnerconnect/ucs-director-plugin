package com.cloupia.feature.purestorage.accounts;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.tree.MoReference;


@XmlRootElement(name = "FlashArray_Volume")

@PersistenceCapable(detachable = "true", table = "volume_inventory_config")
public class VolumeInventoryConfig implements TaskConfigIf{
	
	
    // ManagementAddress
    @Persistent
    private String id;
    
    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

   
    public double getSize() {
		return size;
	}


    @MoReference(path = "FlashArray.ID")
    @Persistent
    private String accountName;

    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

    
    public String getAccountName()
    {
        return this.accountName;
    }

    @MoReference(path = "FlashArray.ID.Volume.ID", key = true)
    @Persistent
    private String volumeName;

    
    public String getVolumeName()
    {
        return volumeName;
    }

    
    public void setVolumeName(String volumeName)
    {
        this.volumeName = volumeName;
    }
    
   
    @Persistent
    private double  size;

    
   

    
    public void setSize(double size)
    {
        this.size = size;
    }
    
    @Persistent
    private String source;

    
    public String getSource()
    {
        return source;
    }

    
    public void setSource(String source)
    {
        this.source = source;
    }
    
    @Persistent
    private long creation;

	public long getCreation() {
		return creation;
	}

	public void setCreation(long creation) {
		this.creation = creation;
	}

	@Override
	public long getActionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getDisplayLabel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setActionId(long arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long getConfigEntryId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setConfigEntryId(long arg0) {
		// TODO Auto-generated method stub
		
	}
  }
