package com.cloupia.feature.purestorage.lovs;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.ArrayInventoryConfig;
import com.cloupia.feature.purestorage.accounts.ConnectionArrayInventoryConfig;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.reports.VolumeReport;
import com.cloupia.feature.purestorage.reports.VolumeReportImpl;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.FormLOVPair;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.port.PureArrayPort;
import com.purestorage.rest.volume.PureVolume;

public class ConnectionArrayTabularProvider implements TabularReportGeneratorIf {

	public static final String TABULAR_PROVIDER = "Pure_ConnectionArray_tabular_provider";
	 static Logger logger = Logger.getLogger(ConnectionArrayTabularProvider.class);
	
	

	@Override
	public TabularReport getTabularReportReport(ReportRegistryEntry reportEntry, ReportContext context) throws Exception {
		
		
        TabularReport report = new TabularReport();

		report.setGeneratedTime(System.currentTimeMillis());
		report.setReportName(reportEntry.getReportLabel());
		report.setContext(context);

		TabularReportInternalModel model = new TabularReportInternalModel();
		model.addTextColumn("Account Name", "Account Name");
        model.addTextColumn("Management Address", "Management Address");
        model.addTextColumn("Replication Address", "Replication Address");
        model.addTextColumn("Type", "Type");
        model.addTextColumn("Connection Key","Connection Key");
        model.completedHeader();
		List<PhysicalInfraAccount> accounts = AccountUtil.getAccountsByType("FlashArray");
        
        int i = 0;
        for (PhysicalInfraAccount account:accounts)
        {
      	  
            String accountName = account.getAccountName();
            logger.info("Found account:" + accountName);
            if (accountName != null && accountName.length() > 0)
            {
            	/*FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
                PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
                List<PureVolume> volumes =  CLIENT.volumes().list();*/
            	 List<ConnectionArrayInventoryConfig> ConnectionArrays= PureUtils.getAllPureConnectionArray();
            	 
                 for (ConnectionArrayInventoryConfig ConnectionArray: ConnectionArrays)
                 {
                	 if (accountName.equalsIgnoreCase(ConnectionArray.getAccountName()))
                     {
	                 	//model.addTextValue(volume.getId());
	                 	 model.addTextValue(accountName);
	                 	 model.addTextValue(ConnectionArray.getManagementAddress());
	                 	logger.info("Found account:" + ConnectionArray.getManagementAddress());
	                     model.addTextValue(ConnectionArray.getReplicationAddress());
	                     model.addTextValue(ConnectionArray.getType());
	                     model.addTextValue(ConnectionArray.getVersion());
	                     model.completedRow();
                     }
                 }
            }
        }

		model.updateReport(report);

		return report;
	}

}

