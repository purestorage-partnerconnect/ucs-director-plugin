package com.cloupia.feature.purestorage.tasks;


import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;

import com.cisco.cuic.api.client.WFFieldTypeConstants;
import com.cisco.cuic.api.client.WorkflowInputFieldTypeDeclaration;
import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.HostInventoryConfig;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.fw.objstore.ObjStore;
import com.cloupia.fw.objstore.ObjStoreHelper;
import com.cloupia.service.cIM.inframgr.AbstractTask;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.TaskOutputDefinition;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionLogger;
import com.cloupia.service.cIM.inframgr.customactions.CustomActionTriggerContext;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.protectiongroup.PureProtectionGroup;


public class AddHostProtectionGroupTask extends AbstractTask
{
	static Logger logger = Logger.getLogger(AddHostProtectionGroupTask.class);
	

    @Override
    public void executeCustomAction(CustomActionTriggerContext context, CustomActionLogger actionlogger) throws Exception
    {
    	
    	long configEntryId = context.getConfigEntry().getConfigEntryId();
		//retrieving the corresponding config object for this handler
    	AddHostProtectionGroupTaskConfig config = (AddHostProtectionGroupTaskConfig) context.loadConfigObject();
		 PureRestClient CLIENT = null;
		 String accountName = config.getAccountName();
        actionlogger.addInfo("finished checking task accoutname");
        FlashArrayAccount flashArrayAccount = FlashArrayAccount.getFlashArrayCredential(accountName);
        CLIENT = PureUtils.ConstructPureRestClient(flashArrayAccount);

         String hostName = config.getHostName();
        String protectionGroupName = config.getProtectionGroup();
        
        List<PureProtectionGroup> protectiongroups =  CLIENT.protectionGroups().list();
       

            try
            {
                CLIENT.protectionGroups().addHosts(protectionGroupName, Arrays.asList(hostName));
            }
            catch(Exception e) {
                actionlogger.addError("Please check the Protection Group Name " + protectionGroupName + "and host Details.");
                throw e;
            }

           
            
             actionlogger.addInfo("Added host " + hostName + " in Protection Group on Pure FlashArray [" + flashArrayAccount.getManagementAddress() + "]");
        
           context.getChangeTracker().undoableResourceModified("Added Hosts in Protection Group", "Added Hosts in Protection Group", "Added Hosts in Protection Group",
                    "Added Hosts in Protection Group" + config.getAccountName(),
                    new RemoveHostProtectionGroupTask().getTaskName(), new RemoveHostProtectionGroupTaskConfig(config));
            String hostIdentity =accountName+"@"+hostName;
            //String snapIdentity =accountName+"@"+snapShotName;
            
            
        	context.saveOutputValue(PureConstants.TASK_OUTPUT_NAME_HOST_IDENTITY, hostIdentity);
        	actionlogger.addInfo("Host Identity as Output is saved");
        	
        	String addedHost="";
        	ObjStore<ProtectionGroupInventoryConfig> store2 = ObjStoreHelper.getStore(ProtectionGroupInventoryConfig.class);
       	   
            String query3 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgconfig = store2.query(query3);
            actionlogger.addInfo("Protection Group ID :"+ pgconfig.get(0).getId());
            //pgconfig.get(0).getHosts();
            String hostsList1= pgconfig.get(0).getHosts();
            
            actionlogger.addInfo(" Host :"+ hostsList1);
    		
    				if(hostsList1 == "")
    					{
    						pgconfig.get(0).setHosts(hostName);;
    					}else
    						{
    						hostsList1=hostsList1+","+hostName;
    						pgconfig.get(0).setHosts(hostsList1);
    						}
          
           
            
            store2.modifySingleObject("hosts == '" + hostsList1 + "'",  pgconfig.get(0));
            String query4 = "id == '" + accountName+"@"+protectionGroupName + "'";
            List<ProtectionGroupInventoryConfig> pgconfig1 = store2.query(query4);
            actionlogger.addInfo("Host Name :"+ pgconfig1.get(0).getHosts());
            
            }
    
   
    
    
          
        
        

    
    @Override
	public TaskOutputDefinition[] getTaskOutputDefinitions()
    {
    	TaskOutputDefinition[] ops = new TaskOutputDefinition[1];
   		

   		ops[0] = new TaskOutputDefinition(
   				PureConstants.TASK_OUTPUT_NAME_HOST_IDENTITY,
   				WFFieldTypeConstants.GENERIC_TEXT,
   				"Host Identity");
        
        return ops;
    }
	@Override
	public TaskConfigIf getTaskConfigImplementation() {
		// TODO Auto-generated method stub
		return new AddHostProtectionGroupTaskConfig();
	}
	@Override
	public String getTaskName() {
		// TODO Auto-generated method stub
		return PureConstants.TASK_NAME_ADD_HOST_PROTECTIONGROUP_TASK;
	}

}