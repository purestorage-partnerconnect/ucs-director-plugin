package com.cloupia.feature.purestorage.lovs;


import com.cloupia.service.cIM.inframgr.forms.wizard.LOVProviderIf;
import com.cloupia.service.cIM.inframgr.forms.wizard.WizardSession;
import com.cloupia.model.cIM.FormLOVPair;


public class ArrayTypeProvider implements LOVProviderIf
{

    public static final String NAME = "pure_array_type_lov_provider";

    @Override
    public FormLOVPair[] getLOVs(WizardSession session)
    {
        FormLOVPair[] pairs = new FormLOVPair[2];
        pairs[0] = new FormLOVPair("Sync Replication", "replication");
        pairs[1] = new FormLOVPair("Async Replication", "async-replication");
       
        return pairs;
    }

}