package com.cloupia.feature.purestorage.actions.forms;

import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;

public class ScheduleVolumeSnapshotForm {
	

	

	@FormField(label = "Snapshot Suffix Name", help = "Letters, numbers, -, and _", mandatory = true )
    private String suffix;
   
	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
    
}
