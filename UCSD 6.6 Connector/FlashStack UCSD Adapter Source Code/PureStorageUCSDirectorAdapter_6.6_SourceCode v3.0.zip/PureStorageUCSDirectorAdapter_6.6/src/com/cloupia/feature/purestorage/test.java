package com.cloupia.feature.purestorage;

import com.cloupia.feature.purestorage.constants.PureConstants;
import com.purestorage.rest.AbstractPureRestClient;
import com.purestorage.rest.PureApiVersion;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.PureRestClientConfig;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Hellooo6y7u5ooooooooooooooo");
System.out.println("Helloooooooooooooooooo3434");
String apiEndPoint = "https://172.16.239.10/api";
PureApiVersion restAPIversion = PureApiVersion.fromString("1.7");
System.out.println(":Connecting to Pure FlashArray at [" + apiEndPoint + "] with username [" + "]");
PureRestClientConfig CONFIG = PureRestClientConfig.newBuilder("pureuser", "pureuser", apiEndPoint, restAPIversion)//10.203.128.141
        .setClientInfo(PureConstants.PURE_ADAPTER_NAME, PureConstants.PURE_ADAPTER_VERSION)
        .setIgnoreCertificateError(true)
       .build();

PureRestClient CLIENT = AbstractPureRestClient.create(CONFIG);
System.out.println(CLIENT.array().getAttributes());

	}

}
