package com.cloupia.feature.purestorage.accounts;

import javax.jdo.annotations.Column;
import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.tree.MoReference;


@XmlRootElement(name = "FlashArray_HostGroup")

@PersistenceCapable(detachable = "true", table = "host_group_inventory_configg")
public class HostGroupInventoryConfig implements TaskConfigIf{


    static Logger logger = Logger.getLogger(HostGroupInventoryConfig.class);

    // ManagementAddress
    @Persistent
    private String id;
    
    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    @MoReference(path = "FlashArray.ID")
    @Persistent
    private String accountName;
    
    @MoReference(path = "FlashArray.ID.HostGroup.ID", key = true)
    @Persistent
    private String hostGroupName;
    
    @Persistent
    private int hosts;
    
    @Persistent
    private int volumes;
    
    @Persistent
    @Column(length = 1024000000, jdbcType = "CLOB")
    private String connectedVolumes;
    

	@Persistent
    private double provisionedSize;
	
	@Persistent
    private double volumeCapacity;
	
	@Persistent
    private double reduction;
	
	@Persistent
	String hostsList;

	public String getHostsList() {
		return hostsList;
	}

	public void setHostsList(String hostsList) {
		this.hostsList = hostsList;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getHostGroupName() {
		return hostGroupName;
	}

	public void setHostGroupName(String hostGroupName) {
		this.hostGroupName = hostGroupName;
	}

	public int getHosts() {
		return hosts;
	}

	public void setHosts(int hosts) {
		this.hosts = hosts;
	}

	public int getVolumes() {
		return volumes;
	}

	public void setVolumes(int volumes) {
		this.volumes = volumes;
	}

	public String getConnectedVolumes() {
		return connectedVolumes;
	}

	public void setConnectedVolumes(String connectedVolumes) {
		this.connectedVolumes = connectedVolumes;
	}

	public double getProvisionedSize() {
		return provisionedSize;
	}

	public void setProvisionedSize(double provisionedSize) {
		this.provisionedSize = provisionedSize;
	}

	public double getVolumeCapacity() {
		return volumeCapacity;
	}

	public void setVolumeCapacity(double volumeCapacity) {
		this.volumeCapacity = volumeCapacity;
	}

	public double getReduction() {
		return reduction;
	}

	public void setReduction(double reduction) {
		this.reduction = reduction;
	}

	@Override
	public long getActionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getDisplayLabel() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setActionId(long arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public long getConfigEntryId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setConfigEntryId(long arg0) {
		// TODO Auto-generated method stub
		
	}
    
    
   
   
  }
