package com.cloupia.feature.purestorage.tasks;


import com.cloupia.feature.purestorage.constants.PureConstants;
import com.cloupia.feature.purestorage.lovs.FlashArrayAccountsNameProvider;
import com.cloupia.feature.purestorage.lovs.HostTabularProvider;
import com.cloupia.feature.purestorage.lovs.PodTabularProvider;
import com.cloupia.model.cIM.FormFieldDefinition;
import com.cloupia.service.cIM.inframgr.TaskConfigIf;
import com.cloupia.service.cIM.inframgr.customactions.UserInputField;
import com.cloupia.service.cIM.inframgr.customactions.WorkflowInputFieldTypeDeclaration;
import com.cloupia.service.cIM.inframgr.forms.wizard.FormField;
import com.cloupia.service.cIM.tree.MoReference;

import javax.jdo.annotations.PersistenceCapable;
import javax.jdo.annotations.Persistent;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "FlashArrayDeletePod")
@PersistenceCapable(detachable = "true", table = "psucs_delete_pod_task_config")
public class DeletePodTaskConfig implements TaskConfigIf
{

    @FormField(label = "FlashArray Account", help = "FlashArray Account", mandatory=true, type=FormFieldDefinition.FIELD_TYPE_EMBEDDED_LOV,
            lovProvider = FlashArrayAccountsNameProvider.NAME)
    @UserInputField(type = PureConstants.PURE_FLASHARRAY_ACCOUNT_LOV_NAME)
    @Persistent
    private String accountName;

    @MoReference(path = "FlashArray.ID.Pod.ID", key = true)
    @FormField(label = "Pod Name", help = "FlashArray Pod Name",  mandatory = true,type=FormFieldDefinition.FIELD_TYPE_TABULAR_POPUP, table=PodTabularProvider.TABULAR_PROVIDER)
    @UserInputField(type = PureConstants.PURE_POD_TABLE_NAME)
    @Persistent
    private String podName;

    
    
    @Persistent
    private long configEntryId;

    @Persistent
    private long actionId;


    @Override
    public long getActionId(){ return actionId;}

    @Override
    public long getConfigEntryId(){return configEntryId;}

 

    @Override
	public void setActionId(long arg0) {
		this.actionId = arg0;

	}

	@Override
	public void setConfigEntryId(long arg0) {
		this.configEntryId = arg0;

	}

    public DeletePodTaskConfig(){};

    public DeletePodTaskConfig(NewPodTaskConfig config)
    {
        this.accountName = config.getAccountName();
        this.podName = config.getPodName();
        
    }

    @Override
	public String getDisplayLabel()
    {
        return PureConstants.TASK_NAME_DELETE_POD;
    }

    public String getAccountName()
    {
        return accountName;
    }
    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

	public String getPodName() {
		return podName;
	}

	public void setPodName(String podName) {
		this.podName = podName;
	}
   


}
