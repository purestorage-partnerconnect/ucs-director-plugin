package com.cloupia.feature.purestorage.lovs;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cloupia.feature.purestorage.PureUtils;
import com.cloupia.feature.purestorage.accounts.FlashArrayAccount;
import com.cloupia.feature.purestorage.accounts.ProtectionGroupInventoryConfig;
import com.cloupia.feature.purestorage.accounts.SubnetInventoryConfig;
import com.cloupia.feature.purestorage.accounts.VolumeInventoryConfig;
import com.cloupia.feature.purestorage.reports.VolumeReport;
import com.cloupia.feature.purestorage.reports.VolumeReportImpl;
import com.cloupia.lib.connector.account.AccountUtil;
import com.cloupia.lib.connector.account.PhysicalInfraAccount;
import com.cloupia.model.cIM.FormLOVPair;
import com.cloupia.model.cIM.ReportContext;
import com.cloupia.model.cIM.TabularReport;
import com.cloupia.service.cIM.inframgr.TabularReportGeneratorIf;
import com.cloupia.service.cIM.inframgr.reportengine.ReportRegistryEntry;
import com.cloupia.service.cIM.inframgr.reports.TabularReportInternalModel;
import com.purestorage.rest.PureRestClient;
import com.purestorage.rest.port.PureArrayPort;
import com.purestorage.rest.volume.PureVolume;

public class SubnetTabularProvider implements TabularReportGeneratorIf {

	public static final String TABULAR_PROVIDER = "Pure_Subnet_tabular_provider";
	 static Logger logger = Logger.getLogger(SubnetTabularProvider.class);
	
	

	@Override
	public TabularReport getTabularReportReport(ReportRegistryEntry reportEntry, ReportContext context) throws Exception {
		
		
        TabularReport report = new TabularReport();

		report.setGeneratedTime(System.currentTimeMillis());
		report.setReportName(reportEntry.getReportLabel());
		report.setContext(context);

		TabularReportInternalModel model = new TabularReportInternalModel();
		model.addTextColumn("Account Name", "Account Name");
		model.addTextColumn("Subnetname", "Subnetname");
        model.addTextColumn("Enabled", "Enabled");
        model.addTextColumn("Gateway", "Gateway");
        model.addTextColumn("Interfaces", "Interfaces");
        model.addTextColumn("Mtu","Mtu");
        
        model.addTextColumn("Prefix", "Prefix");
        model.addTextColumn("Services", "Services");
        model.addTextColumn("Vlan", "Vlan");
        model.completedHeader();
		List<PhysicalInfraAccount> accounts = AccountUtil.getAccountsByType("FlashArray");
        
        int i = 0;
        for (PhysicalInfraAccount account:accounts)
        {
      	  
            String accountName = account.getAccountName();
            logger.info("Found account:" + accountName);
            if (accountName != null && accountName.length() > 0)
            {
            	/*FlashArrayAccount acc = FlashArrayAccount.getFlashArrayCredential(accountName);
                PureRestClient CLIENT = PureUtils.ConstructPureRestClient(acc);
                List<PureVolume> volumes =  CLIENT.volumes().list();*/
            	 List<SubnetInventoryConfig> subnetgroups= PureUtils.getAllPuresubnet();
            	 
                 for (SubnetInventoryConfig subnetgroup: subnetgroups)
                 {
                	 if (accountName.equalsIgnoreCase(subnetgroup.getAccountName()))
                     {
	                 	//model.addTextValue(volume.getId());
	                 	 model.addTextValue(accountName);
	                 	 model.addTextValue(subnetgroup.getSubnetname());
	                 	 model.addTextValue(""+subnetgroup.getEnabled());
	                     model.addTextValue(subnetgroup.getGateway());
	                     model.addTextValue(subnetgroup.getInterfaces());
	                     model.addTextValue(""+subnetgroup.getMtu());
	                    
	                     model.addTextValue(subnetgroup.getPrefix());
	                     model.addTextValue(subnetgroup.getServices());
	                     model.addTextValue(""+subnetgroup.getVlan());
	                     model.completedRow();
                     }
                 }
            }
        }

		model.updateReport(report);

		return report;
	}

}

